# 人格塑形多智能体误信息实验

这个目录用于搭建一套研究型实验框架，用来检验：经过验证的人格塑形，是否会改变多智能体团队在对抗式辩论场景中的误信息识别能力。

## 核心思路

保持以下因素不变：

- 底层模型
- 律师角色设定
- 工具权限
- 辩论协议

只操纵以下变量：

- 人格画像
- 团队组成
- 误信息注入条件

重点观察不同人格或人格组合是否会带来这些差异：

- 更早识别误信息
- 更准确识别误信息
- 产出更有证据支撑的最终结论
- 更少出现误报

## 推荐流程

1. 先验证每个 prompt 是否真的塑造出了目标 Big Five 人格特征。
2. 先跑单智能体基线，再进入多智能体辩论。
3. 比较同质团队和异质团队的表现。
4. 评价时不仅看最终准确率，还要看首个识别时机和证据质量。
5. 先在事实核验任务上跑通，再迁移到法律风格案例。

## 目录说明

- `SPEC.md`：研究问题、假设、实验协议、控制变量和分析方案
- `configs/personas.yaml`：律师型人格配置、目标特征和预期行为
- `configs/conditions.yaml`：实验条件、误信息类型和固定设置
- `prompts/`：agent 提示词模板、辩论流程模板和 judge 评分模板
- `cases/`：案例数据格式和起步样例
- `datasets/README.md`：数据集准备路线
- `analysis/metrics.md`：指标定义和日志记录建议
- `analysis/persona_validation.md`：进入下游任务前的人格验证方案

## 第一阶段目标

第一版可执行实验建议先做到：

- 一个基础模型
- 三种律师人格
- 一个单智能体基线条件
- 一个三智能体异质团队条件
- 一种误信息类型：伪造引文

做到这一步，就已经足够检验这套设计是否能测出可观察的人格效应，再决定是否继续扩展。

## 可执行人格验证

这个目录现在已经补上了一套可运行的原型实现，目标是尽量贴近论文的方法思路：

- 用 `Big Five 1-9` 目标值定义人格
- 用按特质组织的 lexical markers 生成稳定人格提示
- 用 `Likert A-E` 问卷式测量，而不是自由文本自述
- 优先尝试读取选项 `logprobs` 来近似论文中的选项概率打分
- 输出 `CSV + JSON + SVG + HTML` 可视化结果

### 主要文件

- `configs/paper_personas.json`：可执行的人格目标配置
- `configs/trait_markers.json`：按 Big Five 组织的词汇标记库
- `configs/inventories/mini_ipip_20.json`：IPIP 风格短量表
- `run_persona_validation.py`：运行入口
- `src/personality_lab/`：模型调用、人格构造、量表打分、报告生成

### 运行方式

在项目根目录执行：

```powershell
python research\personality-multiagent-misinformation\run_persona_validation.py --persona careful_verifier --model qwen-plus --seeds 3
```

如果你只是先检查流程，不想真的调用大模型，可以运行：

```powershell
python research\personality-multiagent-misinformation\run_persona_validation.py --persona careful_verifier --dry-run
```

### 输出结果

默认会写到：

```text
research/personality-multiagent-misinformation/results/<persona_id>/
```

其中会包含：

- `summary.json`：人格测量摘要
- `responses.csv`：逐题作答记录
- `trait_radar.svg`：目标人格与测得人格雷达图
- `trait_bars.svg`：各维度目标值、均值和稳定性对比图
- `report.html`：可直接打开查看的整合报告

### 说明

这套实现已经比最初的 prompt 草案更接近论文方法，但仍然是“论文启发的可执行近似版”，不是对作者仓库的逐字复刻。最接近论文的部分是：

- 词汇标记驱动的人格塑形
- 连续强度人格目标
- 问卷式人格测量
- 尽量使用选项概率而不是纯文本答案

目前默认使用的是短量表 `mini_ipip_20`，便于快速跑通。后续如果你要更严格地对齐论文，可以继续换成更长的 IPIP 题组，或者接入完整的人格题库。

## 论文式方案库

现在项目里还新增了一套更完整的“论文式人格塑形方案库”：

- 五维 `Big Five 1-9` 连续定制
- 多种 `scheme` 可选
- 命名人格模板
- 自定义人格生成
- 多量表交叉验证
- 自动校准以提高目标命中率

### 方案生成

生成一个命名人格方案包：

```powershell
python research\personality-multiagent-misinformation\generate_persona_plan.py --profile-id forensic_challenger --scheme calibrated_precision
```

生成一个自定义人格方案包：

```powershell
python research\personality-multiagent-misinformation\generate_persona_plan.py --traits E=4,A=3,C=9,N=2,O=7 --label "Custom Auditor" --scheme calibrated_precision
```

### 多量表验证

现在默认会同时使用两套量表：

- `mini_ipip_20`
- `crosscheck_big_five_10`

运行方式例如：

```powershell
python research\personality-multiagent-misinformation\run_persona_validation.py --profile-id careful_verifier --scheme calibrated_precision --seeds 3
```

### 自动校准

如果第一次实测人格偏离目标，可以用校准器自动迭代：

```powershell
python research\personality-multiagent-misinformation\calibrate_persona.py --profile-id careful_verifier --scheme calibrated_precision --iterations 3 --seeds 2
```

### 参考文档

- `论文式塑形方案库.md`
- `项目说明.md`
