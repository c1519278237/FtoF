# Experiment Specification

## Objective

Test whether psychometrically grounded personality shaping causally changes multi-agent performance in misinformation-sensitive debate tasks.

The target application is legal-style reasoning, but the design should first be validated on cleaner fact-verification tasks.

## Main Research Question

When all agents share the same base model, lawyer role, context window, and debate protocol, does personality shaping affect:

- misinformation detection speed
- misinformation detection accuracy
- evidence quality
- group decision quality

## Hypotheses

- `H1`: High-conscientiousness lawyer personas improve misinformation detection accuracy.
- `H2`: Low-agreeableness or high-assertiveness lawyer personas reduce time-to-first-challenge, but may increase false positives.
- `H3`: Heterogeneous teams outperform homogeneous teams on mixed-credibility cases.
- `H4`: Personality effects are stronger when misinformation is subtle, such as forged citations or timeline distortion.

## Independent Variables

### Fixed

- Base model
- Lawyer role framing
- Temperature and generation budget
- Tool permissions
- Debate protocol
- Case materials shown to agents

### Manipulated

- Personality profile
- Team composition
- Misinformation injection type
- Misinformation severity

## Core Controls

To keep the experiment interpretable:

- "Lawyer" is treated as a role, not a personality.
- Every condition uses the same role description.
- Only trait adjectives and trait intensity differ across personality conditions.
- The judge agent must not know which condition produced the debate transcript.

## Two-Stage Evaluation Plan

### Stage 1: Clean Fact Verification

Use FEVER-like or AVeriTeC-style claims to verify that the protocol can produce stable measurements.

Goal:

- low annotation cost
- easy ground truth
- fast iteration on prompts and metrics

### Stage 2: Legal-Style Adversarial Cases

Use legal reasoning cases where misinformation may appear as:

- forged citation
- wrong statute number
- timeline conflict
- selective quotation
- fabricated witness detail

Goal:

- higher ecological validity
- stronger fit with the lawyer-team framing

## Experiment Arms

### Single-Agent

- `single_control`: single agent, lawyer role, no explicit personality shaping
- `single_persona`: single agent, lawyer role, one shaped personality

### Multi-Agent

- `multi_homogeneous`: three agents, same personality
- `multi_heterogeneous`: three agents, different personalities
- `multi_injected_agent`: one agent receives poisoned evidence or false note
- `multi_poisoned_case`: all agents receive the same case bundle with embedded misinformation

The most interpretable first comparison is:

- `single_control`
- `single_persona`
- `multi_homogeneous`
- `multi_heterogeneous`
- `multi_poisoned_case`

## Suggested Team Roles

All agents remain lawyers.
They differ only in shaped personality.

- `careful_verifier`: high conscientiousness, low impulsivity
- `cross_examiner`: lower agreeableness, higher assertiveness
- `open_explorer`: high openness, stronger alternative hypothesis generation
- `consensus_builder`: high agreeableness, strong synthesis

## Debate Protocol

1. Private review
   Each agent reads the case independently and outputs:
   - preliminary verdict
   - suspicious claims
   - evidence table
   - confidence

2. Challenge round
   Agents may challenge only explicit claims, quotes, evidence IDs, or reasoning steps.

3. Evidence round
   Every challenge must cite evidence IDs.
   Unsupported claims do not count toward successful detection.

4. Revision round
   Agents may revise their verdict after seeing criticism.

5. Blind judge decision
   A separate judge scores:
   - final verdict correctness
   - whether misinformation was correctly identified
   - who first identified it
   - evidence quality

## Primary Metrics

- `final_accuracy`: whether the final verdict matches ground truth
- `misinfo_detection_accuracy`: whether the misinformation item was correctly identified
- `first_detection_round`: first round in which misinformation is explicitly and correctly challenged
- `first_detector_identity`: which persona identified it first
- `false_positive_rate`: number of incorrect misinformation flags

## Secondary Metrics

- `evidence_precision`: ratio of correct citations among all cited evidence
- `argument_quality`: rubric score for reasoning quality
- `calibration_error`: confidence versus correctness gap
- `deliberation_cost`: total rounds, tokens, or messages used
- `consensus_shift`: whether the team converges toward the correct answer over rounds

## Logging Requirements

For every run, store:

- seed
- model version
- prompt version
- persona ID
- condition ID
- case ID
- round-by-round messages
- timestamps
- cited evidence IDs
- final verdict
- final confidence

## Statistical Plan

Start with descriptive analysis, then move to:

- logistic regression for final accuracy
- logistic regression for misinformation detection accuracy
- survival analysis or discrete-time hazard modeling for first-detection timing
- mixed-effects models with case ID as a random effect when multiple cases are used

## Minimum Viable Study

The smallest study worth running:

- 1 base model
- 3 personas
- 30 to 50 cases
- 2 misinformation severities
- 3 random seeds per condition

This is enough to estimate whether there is a signal before expanding to larger model or dataset sweeps.

## Main Risks

- personality prompt may change style more than cognition
- legal tasks may be too noisy at first
- some personas may dominate due to verbosity, not reasoning quality
- judge bias may leak if prompt wording exposes the condition

## Mitigations

- validate personality shaping before task runs
- keep message length capped across conditions
- use a blind judge with a fixed rubric
- score both final answer and process traces
