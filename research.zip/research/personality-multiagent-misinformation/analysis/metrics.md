# Metrics and Logging Plan

## Primary Metrics

### Final Accuracy

Whether the final verdict matches the gold case verdict.

### Misinformation Detection Accuracy

Whether the misinformation item is explicitly and correctly identified.

### First Detection Round

The earliest round in which an agent correctly flags the misinformation item and cites supporting evidence.

### False Positive Rate

The number of incorrect misinformation flags divided by the number of flagged items.

## Secondary Metrics

### Evidence Precision

Correctly grounded citations divided by total citations used in decisive reasoning.

### Reasoning Quality

Judge score from 1 to 5 based on:

- internal coherence
- responsiveness to criticism
- justified revision

### Calibration Error

Absolute difference between confidence and correctness, aggregated by condition.

### Deliberation Cost

Any or all of:

- total turns
- total tokens
- total messages

## Suggested Run Log Fields

Store one row per run with at least:

- run_id
- timestamp
- case_id
- arm_id
- model_name
- seed
- agent_ids
- persona_ids
- misinfo_profile_id
- severity
- final_accuracy
- misinfo_detection_accuracy
- first_detection_round
- first_detector_identity
- false_positive_count
- evidence_quality
- reasoning_quality
- deliberation_cost

## Suggested Statistics

- logistic regression for binary outcomes
- mixed-effects models when reusing cases across conditions
- survival-style analysis for time-to-first-detection
- ablations on persona mix and misinformation severity
