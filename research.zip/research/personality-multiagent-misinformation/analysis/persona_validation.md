# Persona Validation Plan

Do not start the main misinformation experiment until personality shaping is checked.

## Why This Step Matters

If the prompt only changes surface tone, then any downstream effect may reflect style, verbosity, or compliance rather than personality.

## Validation Questions

- Does the shaped persona move the intended target trait?
- Does the shaped persona remain stable across seeds?
- Does the shaped persona preserve the shared lawyer role?
- Do non-target traits stay within an acceptable drift range?

## Recommended Procedure

1. Run an unshaped lawyer baseline.
2. Run each shaped lawyer persona on the same personality inventory subset.
3. Score the responses with the same method across conditions.
4. Plot trait differences relative to the baseline lawyer prompt.

## Acceptance Rule

A persona is acceptable for downstream use when:

- the primary target trait shifts in the intended direction
- at least one secondary supporting facet also shifts in the intended direction
- variance across seeds is moderate
- no major role drift appears in the free-text outputs

## Failure Cases

Do not use a persona if:

- it changes tone but not trait score
- it creates large unintended shifts in unrelated traits
- it causes unstable outputs across repeated runs
- it weakens evidence citation behavior

## Minimal Output Table

Record at least:

- persona_id
- seed
- target_trait_score
- non_target_trait_drift
- mean_confidence
- notes_on_role_drift
