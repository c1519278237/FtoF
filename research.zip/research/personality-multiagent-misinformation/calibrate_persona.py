from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.calibration_runner import calibrate_persona
from personality_lab.catalog import parse_trait_targets


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Iteratively calibrate a personality profile toward target Big Five values."
    )
    parser.add_argument("--profile-id", default=None, help="Named profile ID from configs/paper_shaping_library.json")
    parser.add_argument("--traits", default=None, help="Custom trait targets, for example E=3,A=5,C=9,N=3,O=6")
    parser.add_argument("--scheme", default="calibrated_precision", help="Shaping scheme ID")
    parser.add_argument("--label", default=None, help="Custom label when using --traits")
    parser.add_argument("--description", default=None, help="Custom description when using --traits")
    parser.add_argument("--model", default="qwen-plus", help="Model name for the OpenAI-compatible endpoint")
    parser.add_argument("--seeds", type=int, default=2, help="Number of lexical seeds per iteration")
    parser.add_argument("--iterations", type=int, default=3, help="Number of calibration iterations")
    parser.add_argument("--inventories", default=None, help="Comma-separated inventory IDs")
    parser.add_argument("--output-dir", default=None, help="Output directory. Defaults to calibration/<profile_name>")
    parser.add_argument("--dry-run", action="store_true", help="Skip the remote model call and simulate calibration.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    trait_targets = parse_trait_targets(args.traits) if args.traits else None
    inventory_ids = [item.strip() for item in args.inventories.split(",")] if args.inventories else None
    output_name = args.profile_id or (args.label.lower().replace(" ", "_") if args.label else "custom_profile")
    output_dir = Path(args.output_dir) if args.output_dir else PROJECT_ROOT / "calibration" / output_name
    final_dir = calibrate_persona(
        profile_id=args.profile_id,
        trait_targets=trait_targets,
        label=args.label,
        description=args.description,
        scheme_id=args.scheme,
        inventory_ids=inventory_ids,
        model_name=args.model,
        seed_count=args.seeds,
        iterations=args.iterations,
        output_dir=output_dir,
        dry_run=args.dry_run,
    )
    print(f"Calibration artifacts written to: {final_dir}")


if __name__ == "__main__":
    main()
