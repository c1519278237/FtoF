# Dataset Roadmap

## Stage 1: Fast Validation

Use a fact-verification dataset before moving into legal-style cases.

Recommended options:

- FEVER-style claim verification
- AVeriTeC-style claim verification
- internally curated short factual disputes with gold evidence IDs

Why start here:

- cleaner ground truth
- easier scoring
- faster prompt iteration
- lower risk of legal-domain noise hiding the personality effect

## Stage 2: Legal-Style Cases

After the protocol is stable, build a small legal-style benchmark.

Case sources can include:

- synthetic cases authored from public legal writing patterns
- manually curated public-domain case summaries
- contract disputes, notice disputes, timeline disputes, witness credibility disputes

Recommended misinformation profiles:

- forged citation
- wrong statute number
- selective quotation
- timeline conflict
- fabricated witness detail

## Annotation Requirements

Every case should include:

- gold final verdict
- gold supporting evidence IDs
- explicit misinformation item IDs
- severity level
- short explanation of why the item is false or misleading

## Initial Scope

Target a starter benchmark of:

- 30 to 50 total cases
- at least 10 cases per misinformation type
- both obvious and subtle severities where possible

That is enough to estimate effect size before scaling.
