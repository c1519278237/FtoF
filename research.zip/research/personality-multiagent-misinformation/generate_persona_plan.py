from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.catalog import build_custom_profile, load_shaping_library, parse_trait_targets, resolve_profile, resolve_scheme
from personality_lab.json_utils import dump_json
from personality_lab.persona import TRAIT_LABELS, TRAIT_ORDER, build_persona_prompt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a paper-inspired personality shaping plan and prompt package."
    )
    parser.add_argument("--profile-id", default=None, help="Named profile ID from configs/paper_shaping_library.json")
    parser.add_argument("--traits", default=None, help="Custom trait targets, for example E=3,A=5,C=9,N=3,O=6")
    parser.add_argument("--scheme", default="calibrated_precision", help="Shaping scheme ID")
    parser.add_argument("--label", default=None, help="Custom label when using --traits")
    parser.add_argument("--description", default=None, help="Custom description when using --traits")
    parser.add_argument("--lexical-seed", type=int, default=1, help="Lexical seed for marker selection")
    parser.add_argument("--output-dir", default=None, help="Output directory. Defaults to generated_profiles/<name>")
    return parser.parse_args()


def build_markdown(profile: dict, scheme: dict, prompt_bundle, targets: dict) -> str:
    rows = []
    for trait in TRAIT_ORDER:
        trait_instruction = prompt_bundle.trait_instructions.get(trait, "Baseline control mode; no explicit trait shaping.")
        marker_summary = prompt_bundle.marker_summary.get(trait, {})
        rows.append(
            "\n".join(
                [
                    f"## {TRAIT_LABELS[trait]}",
                    f"- 目标分数: `{targets[trait]}/9`",
                    f"- 方案说明: {trait_instruction}",
                    f"- 高方向词: {', '.join(marker_summary.get('high', [])) or 'N/A'}",
                    f"- 低方向词: {', '.join(marker_summary.get('low', [])) or 'N/A'}",
                ]
            )
        )
    return "\n\n".join(
        [
            f"# {profile['label']} 论文式人格塑形方案",
            "",
            f"- 方案 ID: `{scheme['id']}`",
            f"- 方案说明: {scheme['description']}",
            f"- Persona ID: `{profile['id']}`",
            f"- 用途: {profile.get('use_case', 'Custom profile')}",
            "",
            "## 五维目标",
            *(f"- `{TRAIT_LABELS[trait]}` = `{targets[trait]}/9`" for trait in TRAIT_ORDER),
            "",
            "## 生成的系统提示词",
            "```text",
            prompt_bundle.system_prompt,
            "```",
            "",
            *rows,
        ]
    )


def main() -> None:
    args = parse_args()
    library = load_shaping_library()
    scheme = resolve_scheme(library, args.scheme)

    trait_targets = parse_trait_targets(args.traits) if args.traits else None
    profile = resolve_profile(
        library,
        profile_id=args.profile_id,
        trait_targets=trait_targets,
        label=args.label,
        description=args.description,
        recommended_scheme=args.scheme,
    )

    prompt_bundle = build_persona_prompt(
        library["shared_role"],
        profile,
        library,
        args.scheme,
        lexical_seed=args.lexical_seed,
    )

    output_name = profile["id"]
    output_dir = Path(args.output_dir) if args.output_dir else PROJECT_ROOT / "generated_profiles" / output_name
    output_dir.mkdir(parents=True, exist_ok=True)

    targets = profile["trait_targets"]
    dump_json(output_dir / "profile_spec.json", profile)
    dump_json(
        output_dir / "plan_summary.json",
        {
            "profile": profile,
            "scheme": scheme,
            "trait_instructions": prompt_bundle.trait_instructions,
            "marker_summary": prompt_bundle.marker_summary,
            "system_prompt": prompt_bundle.system_prompt,
        },
    )
    output_dir.joinpath("system_prompt.txt").write_text(prompt_bundle.system_prompt, encoding="utf-8")
    output_dir.joinpath("方案说明.md").write_text(
        build_markdown(profile, scheme, prompt_bundle, targets),
        encoding="utf-8",
    )
    print(f"Generated persona plan at: {output_dir}")


if __name__ == "__main__":
    main()
