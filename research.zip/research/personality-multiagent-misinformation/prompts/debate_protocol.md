# Debate Protocol Template

Use this protocol for every condition so that personality is the main manipulated factor.

## Round 0: Private Review

Each agent receives the same task prompt:

1. Read the case packet.
2. Produce a preliminary verdict.
3. List suspicious claims with evidence IDs.
4. Give a confidence score.

## Round 1: Challenge

Each agent may challenge:

- a claim
- a citation
- a quotation
- a timeline inference

Each challenge must identify:

- target agent
- target claim
- evidence IDs
- reason for suspicion

## Round 2: Evidence Defense

Each challenged agent must either:

- defend the claim with evidence IDs
- revise the claim
- withdraw the claim

## Round 3: Final Revision

Each agent outputs:

- final verdict
- whether misinformation was present
- most decisive evidence IDs
- final confidence

## Judge Step

The judge reads only:

- case packet
- full debate transcript
- gold annotations

The judge must score:

- final verdict correctness
- whether misinformation was correctly identified
- round of first correct identification
- identity of first correct detector
- false-positive count
- evidence quality

## Optional Guardrails

- max 180 words per turn
- max 3 explicit challenges per round
- no appeal to hidden knowledge outside the case packet unless the condition explicitly allows retrieval
