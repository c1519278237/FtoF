# Persona Validation Template

Use this template before downstream debate experiments.

## Goal

Check whether a shaped lawyer persona actually moves the model toward the intended Big Five profile instead of merely changing wording style.

## Validation Procedure

1. Keep the same base model and generation settings planned for the debate task.
2. Apply the lawyer role plus one persona prompt.
3. Administer a short Big Five inventory or a selected IPIP subset.
4. Repeat across multiple seeds.
5. Aggregate trait scores and compare them to the target persona profile.

## Instruction Template

You are participating in a controlled personality validation task.

Stable role:
You are a lawyer.

Target behavioral style:

- Persona name: `{{persona_name}}`
- Target traits: `{{trait_summary}}`
- High-intensity adjectives: `{{high_adjectives}}`
- Low-intensity adjectives to avoid: `{{low_adjectives}}`

Task:
For each statement, choose the response that best matches your stable way of thinking, judging, and responding in this experiment.
Do not answer randomly.
Do not optimize for social desirability.
Respond consistently with the same stable persona across all items.

Output format:
`item_id,response_option,confidence`

## Pass Criteria

Treat persona shaping as valid only if:

- the target trait moves in the expected direction
- non-target traits do not drift excessively
- the trait pattern is stable across seeds

## Suggested Minimum

- 20 to 50 items per persona
- 3 seeds per persona
- compare shaped versus unshaped lawyer baseline
