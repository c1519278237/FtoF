from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.benchmark_runner import rebuild_benchmark_suite_outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebuild benchmark aggregate outputs from existing per-profile results."
    )
    parser.add_argument(
        "--suite-config",
        required=True,
        help="Path to the benchmark suite config JSON.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory that already contains per-profile result folders.",
    )
    parser.add_argument("--model", default=None, help="Optional model name override for metadata.")
    parser.add_argument("--dry-run", action="store_true", help="Mark rebuilt report as dry-run.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    final_dir = rebuild_benchmark_suite_outputs(
        suite_config_path=Path(args.suite_config),
        output_dir=Path(args.output_dir),
        dry_run=args.dry_run,
        model_name=args.model,
    )
    print(f"Benchmark aggregate report rebuilt at: {final_dir}")


if __name__ == "__main__":
    main()
