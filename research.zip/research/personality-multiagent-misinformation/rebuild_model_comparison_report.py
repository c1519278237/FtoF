from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.model_comparison_runner import rebuild_model_comparison_outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebuild a cross-model comparison report from existing model benchmark folders."
    )
    parser.add_argument(
        "--comparison-config",
        required=True,
        help="Path to the multi-model comparison config JSON.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory that contains per-model benchmark folders.",
    )
    parser.add_argument(
        "--benchmark-suite",
        default=None,
        help="Optional benchmark suite config override.",
    )
    parser.add_argument(
        "--models",
        default=None,
        help="Comma-separated model aliases to include.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Mark rebuilt report as dry-run.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    selected_models = [item.strip() for item in args.models.split(",")] if args.models else None
    benchmark_suite_path = Path(args.benchmark_suite) if args.benchmark_suite else None
    final_dir = rebuild_model_comparison_outputs(
        comparison_config_path=Path(args.comparison_config),
        output_dir=Path(args.output_dir),
        benchmark_suite_path=benchmark_suite_path,
        selected_models=selected_models,
        dry_run=args.dry_run,
    )
    print(f"Model comparison report rebuilt at: {final_dir}")


if __name__ == "__main__":
    main()
