from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.model_comparison_runner import run_model_comparison_suite


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a cross-model benchmark for personality shaping accuracy, stability, and adaptability."
    )
    parser.add_argument(
        "--comparison-config",
        default="research\\personality-multiagent-misinformation\\configs\\model_comparison_suite.json",
        help="Path to the multi-model comparison config JSON.",
    )
    parser.add_argument(
        "--benchmark-suite",
        default=None,
        help="Optional benchmark suite config override.",
    )
    parser.add_argument(
        "--models",
        default=None,
        help="Comma-separated model aliases from configs/model_registry.json.",
    )
    parser.add_argument(
        "--output-dir",
        default="research\\personality-multiagent-misinformation\\benchmark_runs\\model_adaptation_benchmark_v1",
        help="Directory for cross-model outputs.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run without remote model calls.",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Continue running remaining models if one model fails.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    selected_models = [item.strip() for item in args.models.split(",")] if args.models else None
    benchmark_suite_path = Path(args.benchmark_suite) if args.benchmark_suite else None
    final_dir = run_model_comparison_suite(
        comparison_config_path=Path(args.comparison_config),
        output_dir=Path(args.output_dir),
        benchmark_suite_path=benchmark_suite_path,
        selected_models=selected_models,
        dry_run=args.dry_run,
        continue_on_error=args.continue_on_error,
    )
    print(f"Model comparison report written to: {final_dir}")


if __name__ == "__main__":
    main()
