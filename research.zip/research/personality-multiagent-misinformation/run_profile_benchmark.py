from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from personality_lab.benchmark_runner import run_benchmark_suite


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a multi-profile benchmark and generate an aggregate scientific summary."
    )
    parser.add_argument(
        "--suite-config",
        default="research\\personality-multiagent-misinformation\\configs\\benchmark_profiles_expanded.json",
        help="Path to the benchmark suite config JSON."
    )
    parser.add_argument(
        "--output-dir",
        default="research\\personality-multiagent-misinformation\\benchmark_runs\\paper_style_profile_benchmark_v2_expanded",
        help="Directory for benchmark outputs."
    )
    parser.add_argument("--model", default=None, help="Optional model override.")
    parser.add_argument("--dry-run", action="store_true", help="Run the suite in dry-run mode.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = run_benchmark_suite(
        suite_config_path=Path(args.suite_config),
        output_dir=Path(args.output_dir),
        model_name=args.model,
        dry_run=args.dry_run,
    )
    print(f"Benchmark report written to: {output_dir}")


if __name__ == "__main__":
    main()
