"""Runnable tools for paper-inspired personality shaping and validation."""
