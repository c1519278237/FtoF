from __future__ import annotations

import csv
import math
from collections import defaultdict
from datetime import datetime
from html import escape
from pathlib import Path
from statistics import mean
from typing import Dict, List

from .json_utils import dump_json, load_json
from .persona import TRAIT_LABELS, TRAIT_ORDER
from .validation_runner import run_persona_validation


def run_benchmark_suite(
    *,
    suite_config_path: Path,
    output_dir: Path,
    model_name: str | None = None,
    dry_run: bool = False,
) -> Path:
    suite = load_json(suite_config_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    summaries = []

    for profile_cfg in suite["profiles"]:
        profile_id = profile_cfg["profile_id"]
        profile_output_dir = output_dir / profile_id
        inventories = profile_cfg.get("inventory_ids") or suite.get("default_inventories")
        result_dir = run_persona_validation(
            profile_id=profile_id,
            scheme_id=profile_cfg.get("scheme_id"),
            inventory_ids=inventories,
            model_name=model_name or suite.get("default_model", "qwen-plus"),
            seed_count=int(profile_cfg.get("seed_count", 3)),
            output_dir=profile_output_dir,
            dry_run=dry_run,
            control_targets=profile_cfg.get("control_traits"),
        )
        summary = load_json(result_dir / "summary.json")
        summary["benchmark_notes"] = profile_cfg.get("notes", "")
        summaries.append(summary)

    aggregate = build_aggregate_summary(
        suite=suite,
        summaries=summaries,
        output_dir=output_dir,
        dry_run=dry_run,
        model_name=model_name or suite.get("default_model", "qwen-plus"),
    )
    write_benchmark_outputs(output_dir, aggregate)
    return output_dir


def rebuild_benchmark_suite_outputs(
    *,
    suite_config_path: Path,
    output_dir: Path,
    dry_run: bool = False,
    model_name: str | None = None,
) -> Path:
    suite = load_json(suite_config_path)
    summaries = []
    for profile_cfg in suite["profiles"]:
        profile_id = profile_cfg["profile_id"]
        summary_path = output_dir / profile_id / "summary.json"
        if not summary_path.exists():
            raise RuntimeError(f"Missing summary for profile '{profile_id}': {summary_path}")
        summary = load_json(summary_path)
        summary["benchmark_notes"] = profile_cfg.get("notes", "")
        summaries.append(summary)
    aggregate = build_aggregate_summary(
        suite=suite,
        summaries=summaries,
        output_dir=output_dir,
        dry_run=dry_run,
        model_name=model_name or suite.get("default_model", "qwen-plus"),
    )
    write_benchmark_outputs(output_dir, aggregate)
    return output_dir


def build_aggregate_summary(
    *,
    suite: Dict[str, object],
    summaries: List[Dict[str, object]],
    output_dir: Path,
    dry_run: bool,
    model_name: str,
) -> Dict[str, object]:
    model_metadata = summaries[0] if summaries else {}
    profiles = []
    trait_rows = []

    for summary in summaries:
        traits = summary["traits"]
        abs_errors = [abs(traits[trait]["mean"] - traits[trait]["target"]) for trait in TRAIT_ORDER]
        trait_stds = [traits[trait]["std"] for trait in TRAIT_ORDER]
        inventory_gaps = [traits[trait]["inventory_gap"] for trait in TRAIT_ORDER]
        profile_row = {
            "profile_id": summary["profile_id"],
            "persona_label": summary["persona_label"],
            "scheme_id": summary["scheme_id"],
            "seed_count": summary["seed_count"],
            "used_logprobs": summary["used_logprobs"],
            "mean_absolute_error": summary["mean_absolute_error"],
            "mean_trait_std": round(mean(trait_stds), 4),
            "mean_inventory_gap": round(mean(inventory_gaps), 4),
            "max_abs_error": round(max(abs_errors), 4),
            "notes": summary.get("benchmark_notes", ""),
            "report_path": f"{summary['profile_id']}/report.html",
        }
        for trait in TRAIT_ORDER:
            target_value = float(traits[trait]["target"])
            mean_value = float(traits[trait]["mean"])
            std_value = float(traits[trait]["std"])
            inventory_gap = float(traits[trait]["inventory_gap"])
            abs_error = abs(mean_value - target_value)
            bias = mean_value - target_value
            profile_row[f"{trait}_target"] = target_value
            profile_row[f"{trait}_mean"] = mean_value
            profile_row[f"{trait}_std"] = std_value
            profile_row[f"{trait}_abs_error"] = round(abs_error, 4)
            profile_row[f"{trait}_bias"] = round(bias, 4)
            profile_row[f"{trait}_inventory_gap"] = inventory_gap
            trait_rows.append(
                {
                    "profile_id": summary["profile_id"],
                    "persona_label": summary["persona_label"],
                    "scheme_id": summary["scheme_id"],
                    "trait": trait,
                    "trait_label": TRAIT_LABELS[trait],
                    "target": target_value,
                    "mean": mean_value,
                    "std": std_value,
                    "abs_error": round(abs_error, 4),
                    "bias": round(bias, 4),
                    "inventory_gap": inventory_gap,
                }
            )
        profiles.append(profile_row)

    trait_aggregate = {}
    for trait in TRAIT_ORDER:
        rows = [row for row in trait_rows if row["trait"] == trait]
        most_accurate = min(rows, key=lambda row: row["abs_error"])
        least_accurate = max(rows, key=lambda row: row["abs_error"])
        trait_aggregate[trait] = {
            "trait_label": TRAIT_LABELS[trait],
            "mean_abs_error": round(mean(row["abs_error"] for row in rows), 4),
            "mean_bias": round(mean(row["bias"] for row in rows), 4),
            "mean_std": round(mean(row["std"] for row in rows), 4),
            "mean_inventory_gap": round(mean(row["inventory_gap"] for row in rows), 4),
            "mean_target": round(mean(row["target"] for row in rows), 4),
            "mean_measured": round(mean(row["mean"] for row in rows), 4),
            "target_measured_correlation": round(
                _pearson([row["target"] for row in rows], [row["mean"] for row in rows]),
                4,
            ),
            "most_accurate_profile": {
                "profile_id": most_accurate["profile_id"],
                "persona_label": most_accurate["persona_label"],
                "abs_error": most_accurate["abs_error"],
            },
            "least_accurate_profile": {
                "profile_id": least_accurate["profile_id"],
                "persona_label": least_accurate["persona_label"],
                "abs_error": least_accurate["abs_error"],
            },
        }

    ranking = sorted(
        [
            {
                "profile_id": row["profile_id"],
                "persona_label": row["persona_label"],
                "mean_absolute_error": row["mean_absolute_error"],
            }
            for row in profiles
        ],
        key=lambda item: item["mean_absolute_error"],
    )
    stability_ranking = sorted(
        [
            {
                "profile_id": row["profile_id"],
                "persona_label": row["persona_label"],
                "mean_trait_std": row["mean_trait_std"],
            }
            for row in profiles
        ],
        key=lambda item: item["mean_trait_std"],
    )

    pairwise_rows = build_pairwise_rows(profiles)
    scheme_rows = build_scheme_aggregate_rows(profiles)
    profile_separation = build_profile_separation(pairwise_rows)

    best_profile = min(profiles, key=lambda row: row["mean_absolute_error"])
    worst_profile = max(profiles, key=lambda row: row["mean_absolute_error"])
    easiest_trait = min(
        trait_aggregate.items(),
        key=lambda item: item[1]["mean_abs_error"],
    )
    hardest_trait = max(
        trait_aggregate.items(),
        key=lambda item: item[1]["mean_abs_error"],
    )
    strongest_bias_trait = max(
        trait_aggregate.items(),
        key=lambda item: abs(item[1]["mean_bias"]),
    )
    best_scheme = min(scheme_rows, key=lambda row: row["mean_absolute_error"]) if scheme_rows else None

    return {
        "suite_id": suite["suite_id"],
        "description": suite["description"],
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "execution_mode": "dry-run" if dry_run else "live",
        "model": model_name,
        "model_alias": model_metadata.get("model_alias", model_name),
        "model_label": model_metadata.get("model_label", model_name),
        "model_provider": model_metadata.get("model_provider", "unknown"),
        "model_client_type": model_metadata.get("model_client_type", "unknown"),
        "model_source": model_metadata.get("model_source", "unknown"),
        "default_inventories": suite.get("default_inventories", []),
        "output_dir": str(output_dir),
        "profile_count": len(profiles),
        "seed_total": sum(row["seed_count"] for row in profiles),
        "profiles": profiles,
        "traits": trait_rows,
        "trait_aggregate": trait_aggregate,
        "scheme_aggregate": scheme_rows,
        "pairwise_distances": pairwise_rows,
        "profile_separation": profile_separation,
        "ranking": ranking,
        "stability_ranking": stability_ranking,
        "overall_mean_absolute_error": round(mean(row["mean_absolute_error"] for row in profiles), 4),
        "overall_mean_trait_std": round(mean(row["mean_trait_std"] for row in profiles), 4),
        "overall_mean_inventory_gap": round(mean(row["mean_inventory_gap"] for row in profiles), 4),
        "key_findings": build_key_findings(
            best_profile=best_profile,
            worst_profile=worst_profile,
            easiest_trait=easiest_trait,
            hardest_trait=hardest_trait,
            strongest_bias_trait=strongest_bias_trait,
            best_scheme=best_scheme,
            profile_separation=profile_separation,
        ),
    }


def write_benchmark_outputs(output_dir: Path, aggregate: Dict[str, object]) -> None:
    dump_json(output_dir / "aggregate_summary.json", aggregate)
    write_profile_table(output_dir / "profile_table.csv", aggregate["profiles"])
    write_trait_table(output_dir / "trait_table.csv", aggregate["traits"])
    write_scheme_table(output_dir / "scheme_table.csv", aggregate["scheme_aggregate"])
    write_pairwise_table(output_dir / "pairwise_distance_table.csv", aggregate["pairwise_distances"])
    build_profile_trait_matrix_svg(output_dir / "profile_trait_matrix.svg", aggregate)
    build_trait_bias_svg(output_dir / "trait_bias.svg", aggregate)
    build_scheme_comparison_svg(output_dir / "scheme_comparison.svg", aggregate)
    write_markdown_report(output_dir / "总汇总报告.md", aggregate)
    write_interpretation_report(output_dir / "实验结果解读.md", aggregate)
    write_html_report(output_dir / "report.html", aggregate)


def build_pairwise_rows(profiles: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for index, left in enumerate(profiles):
        for right in profiles[index + 1:]:
            left_target = [float(left[f"{trait}_target"]) for trait in TRAIT_ORDER]
            right_target = [float(right[f"{trait}_target"]) for trait in TRAIT_ORDER]
            left_measured = [float(left[f"{trait}_mean"]) for trait in TRAIT_ORDER]
            right_measured = [float(right[f"{trait}_mean"]) for trait in TRAIT_ORDER]
            target_distance = _euclidean(left_target, right_target)
            measured_distance = _euclidean(left_measured, right_measured)
            retention_ratio = measured_distance / target_distance if target_distance else 0.0
            rows.append(
                {
                    "profile_id_a": left["profile_id"],
                    "profile_id_b": right["profile_id"],
                    "scheme_id_a": left["scheme_id"],
                    "scheme_id_b": right["scheme_id"],
                    "same_scheme": left["scheme_id"] == right["scheme_id"],
                    "target_distance": round(target_distance, 4),
                    "measured_distance": round(measured_distance, 4),
                    "distance_retention_ratio": round(retention_ratio, 4),
                }
            )
    return rows


def build_scheme_aggregate_rows(profiles: List[Dict[str, object]]) -> List[Dict[str, object]]:
    grouped: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    for profile in profiles:
        grouped[profile["scheme_id"]].append(profile)

    rows = []
    for scheme_id, scheme_profiles in grouped.items():
        pairwise_rows = build_pairwise_rows(scheme_profiles)
        if pairwise_rows:
            mean_target_distance = mean(row["target_distance"] for row in pairwise_rows)
            mean_measured_distance = mean(row["measured_distance"] for row in pairwise_rows)
            retention_ratio = mean_measured_distance / mean_target_distance if mean_target_distance else 0.0
        else:
            mean_target_distance = 0.0
            mean_measured_distance = 0.0
            retention_ratio = 0.0
        rows.append(
            {
                "scheme_id": scheme_id,
                "profile_count": len(scheme_profiles),
                "mean_absolute_error": round(mean(profile["mean_absolute_error"] for profile in scheme_profiles), 4),
                "mean_trait_std": round(mean(profile["mean_trait_std"] for profile in scheme_profiles), 4),
                "mean_inventory_gap": round(mean(profile["mean_inventory_gap"] for profile in scheme_profiles), 4),
                "mean_target_distance": round(mean_target_distance, 4),
                "mean_measured_distance": round(mean_measured_distance, 4),
                "distance_retention_ratio": round(retention_ratio, 4),
                "profiles": [profile["profile_id"] for profile in scheme_profiles],
            }
        )
    return sorted(rows, key=lambda row: row["mean_absolute_error"])


def build_profile_separation(pairwise_rows: List[Dict[str, object]]) -> Dict[str, object]:
    if not pairwise_rows:
        return {
            "pair_count": 0,
            "mean_target_distance": 0.0,
            "mean_measured_distance": 0.0,
            "distance_retention_ratio": 0.0,
            "closest_target_pair": None,
            "closest_measured_pair": None,
            "farthest_target_pair": None,
            "farthest_measured_pair": None,
        }

    mean_target_distance = mean(row["target_distance"] for row in pairwise_rows)
    mean_measured_distance = mean(row["measured_distance"] for row in pairwise_rows)
    return {
        "pair_count": len(pairwise_rows),
        "mean_target_distance": round(mean_target_distance, 4),
        "mean_measured_distance": round(mean_measured_distance, 4),
        "distance_retention_ratio": round(
            mean_measured_distance / mean_target_distance if mean_target_distance else 0.0,
            4,
        ),
        "closest_target_pair": min(pairwise_rows, key=lambda row: row["target_distance"]),
        "closest_measured_pair": min(pairwise_rows, key=lambda row: row["measured_distance"]),
        "farthest_target_pair": max(pairwise_rows, key=lambda row: row["target_distance"]),
        "farthest_measured_pair": max(pairwise_rows, key=lambda row: row["measured_distance"]),
    }


def build_key_findings(
    *,
    best_profile: Dict[str, object],
    worst_profile: Dict[str, object],
    easiest_trait: tuple[str, Dict[str, object]],
    hardest_trait: tuple[str, Dict[str, object]],
    strongest_bias_trait: tuple[str, Dict[str, object]],
    best_scheme: Dict[str, object] | None,
    profile_separation: Dict[str, object],
) -> List[str]:
    findings = [
        f"最佳塑形人格为 {best_profile['profile_id']}，MAE={best_profile['mean_absolute_error']:.4f}。",
        f"最难塑形人格为 {worst_profile['profile_id']}，MAE={worst_profile['mean_absolute_error']:.4f}。",
        f"最容易控制的维度是 {easiest_trait[1]['trait_label']}，平均绝对误差为 {easiest_trait[1]['mean_abs_error']:.4f}。",
        f"最难控制的维度是 {hardest_trait[1]['trait_label']}，平均绝对误差为 {hardest_trait[1]['mean_abs_error']:.4f}。",
        f"系统性偏差最强的维度是 {strongest_bias_trait[1]['trait_label']}，平均偏差为 {strongest_bias_trait[1]['mean_bias']:.4f}。",
        f"人格分离度保留比例为 {profile_separation['distance_retention_ratio']:.4f}，表示实测人格间距相对目标设计间距的保真度。",
    ]
    if best_scheme:
        findings.append(
            f"当前表现最好的塑形方案是 {best_scheme['scheme_id']}，其平均 MAE 为 {best_scheme['mean_absolute_error']:.4f}。"
        )
    return findings


def write_profile_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "profile_id",
        "persona_label",
        "scheme_id",
        "seed_count",
        "used_logprobs",
        "mean_absolute_error",
        "mean_trait_std",
        "mean_inventory_gap",
        "max_abs_error",
        "notes",
        "report_path",
    ]
    for trait in TRAIT_ORDER:
        fieldnames.extend(
            [
                f"{trait}_target",
                f"{trait}_mean",
                f"{trait}_std",
                f"{trait}_abs_error",
                f"{trait}_bias",
                f"{trait}_inventory_gap",
            ]
        )
    _write_csv(path, rows, fieldnames)


def write_trait_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "profile_id",
        "persona_label",
        "scheme_id",
        "trait",
        "trait_label",
        "target",
        "mean",
        "std",
        "abs_error",
        "bias",
        "inventory_gap",
    ]
    _write_csv(path, rows, fieldnames)


def write_scheme_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "scheme_id",
        "profile_count",
        "mean_absolute_error",
        "mean_trait_std",
        "mean_inventory_gap",
        "mean_target_distance",
        "mean_measured_distance",
        "distance_retention_ratio",
        "profiles",
    ]
    printable_rows = []
    for row in rows:
        printable_row = dict(row)
        printable_row["profiles"] = ",".join(row["profiles"])
        printable_rows.append(printable_row)
    _write_csv(path, printable_rows, fieldnames)


def write_pairwise_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "profile_id_a",
        "profile_id_b",
        "scheme_id_a",
        "scheme_id_b",
        "same_scheme",
        "target_distance",
        "measured_distance",
        "distance_retention_ratio",
    ]
    _write_csv(path, rows, fieldnames)


def write_markdown_report(path: Path, aggregate: Dict[str, object]) -> None:
    ranking_lines = [
        f"{index + 1}. `{item['profile_id']}` (`{item['persona_label']}`), MAE = `{item['mean_absolute_error']:.4f}`"
        for index, item in enumerate(aggregate["ranking"])
    ]
    profile_rows = [
        f"- `{row['profile_id']}`: MAE `{row['mean_absolute_error']:.4f}`，平均跨种子标准差 `{row['mean_trait_std']:.4f}`，平均量表差 `{row['mean_inventory_gap']:.4f}`，scheme `{row['scheme_id']}`。"
        for row in aggregate["profiles"]
    ]
    trait_lines = []
    for trait in TRAIT_ORDER:
        row = aggregate["trait_aggregate"][trait]
        trait_lines.append(
            f"- `{row['trait_label']}`: 平均绝对误差 `{row['mean_abs_error']:.4f}`，平均偏差 `{row['mean_bias']:.4f}`，平均标准差 `{row['mean_std']:.4f}`，目标-实测相关 `{row['target_measured_correlation']:.4f}`。"
        )
    scheme_lines = [
        f"- `{row['scheme_id']}`: 人格数 `{row['profile_count']}`，平均 MAE `{row['mean_absolute_error']:.4f}`，平均标准差 `{row['mean_trait_std']:.4f}`，人格距离保留 `{row['distance_retention_ratio']:.4f}`。"
        for row in aggregate["scheme_aggregate"]
    ]
    finding_lines = [f"- {line}" for line in aggregate["key_findings"]]
    text = "\n".join(
        [
            f"# {aggregate['suite_id']} 总汇总报告",
            "",
            aggregate["description"],
            "",
            "## 实验设置",
            f"- 生成时间：`{aggregate['generated_at']}`",
            f"- 运行模式：`{aggregate['execution_mode']}`",
            f"- 模型：`{aggregate['model']}`",
            f"- 量表：`{', '.join(aggregate['default_inventories'])}`",
            f"- 人格数量：`{aggregate['profile_count']}`",
            f"- 总 lexical seeds：`{aggregate['seed_total']}`",
            "",
            "## 总体指标",
            f"- 总体平均 MAE：`{aggregate['overall_mean_absolute_error']:.4f}`",
            f"- 总体平均跨种子标准差：`{aggregate['overall_mean_trait_std']:.4f}`",
            f"- 总体平均量表差：`{aggregate['overall_mean_inventory_gap']:.4f}`",
            f"- 目标人格平均距离：`{aggregate['profile_separation']['mean_target_distance']:.4f}`",
            f"- 实测人格平均距离：`{aggregate['profile_separation']['mean_measured_distance']:.4f}`",
            f"- 距离保留比例：`{aggregate['profile_separation']['distance_retention_ratio']:.4f}`",
            "",
            "## 关键发现",
            *finding_lines,
            "",
            "## 人格级结果",
            *profile_rows,
            "",
            "## MAE 排名",
            *ranking_lines,
            "",
            "## 维度级统计",
            *trait_lines,
            "",
            "## 方案级比较",
            *scheme_lines,
            "",
            "## 方法学提示",
            "- `MAE` 越低，说明目标人格与实测人格越接近。",
            "- `mean_trait_std` 越低，说明跨 lexical seed 越稳定。",
            "- `mean_inventory_gap` 越低，说明两套量表对同一人格的判断越一致。",
            "- `distance_retention_ratio` 越接近 1，说明不同人格之间的相对间距越能被保留下来。",
            "- 若 `used_logprobs` 普遍为 `false`，表示当前结果主要基于单项 Likert 选项而不是选项概率分布。",
        ]
    )
    path.write_text(text, encoding="utf-8")


def write_interpretation_report(path: Path, aggregate: Dict[str, object]) -> None:
    best_profile = aggregate["ranking"][0]
    worst_profile = aggregate["ranking"][-1]
    best_scheme = aggregate["scheme_aggregate"][0] if aggregate["scheme_aggregate"] else None
    easiest_trait = min(
        TRAIT_ORDER,
        key=lambda trait: aggregate["trait_aggregate"][trait]["mean_abs_error"],
    )
    hardest_trait = max(
        TRAIT_ORDER,
        key=lambda trait: aggregate["trait_aggregate"][trait]["mean_abs_error"],
    )
    strongest_positive_bias = max(
        TRAIT_ORDER,
        key=lambda trait: aggregate["trait_aggregate"][trait]["mean_bias"],
    )
    strongest_negative_bias = min(
        TRAIT_ORDER,
        key=lambda trait: aggregate["trait_aggregate"][trait]["mean_bias"],
    )
    text = "\n".join(
        [
            "# 扩展人格塑形实验结果解读",
            "",
            "## 1. 这轮实验在做什么",
            "",
            "本轮实验把原有的小型人格基准扩展为更大范围的人格筛查，目标是观察：",
            "",
            "- 在统一律师角色下，不同 Big Five 目标人格是否都能被稳定塑造。",
            "- 塑形结果是否会出现系统性偏差。",
            "- 不同塑形方案是否在精度、稳定性和人格分离度上存在差异。",
            "",
            "## 2. 总体结论",
            "",
            f"- 本轮共纳入 `{aggregate['profile_count']}` 个人格，总体平均 MAE 为 `{aggregate['overall_mean_absolute_error']:.4f}`。",
            f"- 最成功的人格是 `{best_profile['profile_id']}`，最困难的人格是 `{worst_profile['profile_id']}`。",
            f"- 最容易控制的维度是 `{aggregate['trait_aggregate'][easiest_trait]['trait_label']}`，最难控制的维度是 `{aggregate['trait_aggregate'][hardest_trait]['trait_label']}`。",
            f"- 实测人格平均距离为 `{aggregate['profile_separation']['mean_measured_distance']:.4f}`，相对于目标设计人格距离的保留比例为 `{aggregate['profile_separation']['distance_retention_ratio']:.4f}`。",
            "",
            "## 3. 对塑形精度的解读",
            "",
            f"- `{best_profile['profile_id']}` 说明当前框架已经能较稳定地塑造出一部分高可控人格原型。",
            f"- `{worst_profile['profile_id']}` 说明仍有一些人格方向会被共享律师角色、模型默认风格或词汇塑形方式拉回中间区域。",
            "",
            "## 4. 对维度偏差的解读",
            "",
            f"- 平均最容易被拉高的维度是 `{aggregate['trait_aggregate'][strongest_positive_bias]['trait_label']}`，平均偏差 `{aggregate['trait_aggregate'][strongest_positive_bias]['mean_bias']:.4f}`。",
            f"- 平均最容易被压低的维度是 `{aggregate['trait_aggregate'][strongest_negative_bias]['trait_label']}`，平均偏差 `{aggregate['trait_aggregate'][strongest_negative_bias]['mean_bias']:.4f}`。",
            f"- `{aggregate['trait_aggregate'][hardest_trait]['trait_label']}` 的平均绝对误差最高，说明这个维度目前最不容易精细控制。",
            "",
            "## 5. 对塑形方案的解读",
            "",
            f"- 最优方案为 `{best_scheme['scheme_id']}`，其平均 MAE 为 `{best_scheme['mean_absolute_error']:.4f}`。" if best_scheme else "- 本轮未得到可比较的 scheme 结果。",
            f"- 若某个 scheme 的 `distance_retention_ratio` 较高，说明它更能把不同人格之间的差异真实保留下来，而不只是把所有人格都塑成一种“好学生律师”。",
            "",
            "## 6. 方法学意义",
            "",
            "- 这轮结果不只是告诉我们“某个人格好不好”，更重要的是揭示了这套人格塑形系统的偏差结构。",
            "- 后续做多智能体误信息博弈时，建议优先使用“实测人格值”而不是“设计目标值”作为分析变量。",
            "- 对表现差的人格，不应直接拿去做下游实验，而应先做单独校准。",
            "",
            "## 7. 当前限制",
            "",
            "- 当前大模型端点未稳定提供可用 logprobs，因此本轮主要基于单项 Likert 选择。",
            "- 当前量表仍是短量表组合，结论适合作为实验筛查和工程迭代依据，但还不是最终心理测量版本。",
            "- 共享律师角色本身会带来角色偏置，这一点必须在论文写作中单独报告。",
        ]
    )
    path.write_text(text, encoding="utf-8")


def write_html_report(path: Path, aggregate: Dict[str, object]) -> None:
    ranking_rows = []
    for row in sorted(aggregate["profiles"], key=lambda item: item["mean_absolute_error"]):
        ranking_rows.append(
            "<tr>"
            f"<td>{escape(row['profile_id'])}</td>"
            f"<td>{escape(row['persona_label'])}</td>"
            f"<td>{escape(row['scheme_id'])}</td>"
            f"<td>{row['seed_count']}</td>"
            f"<td>{row['mean_absolute_error']:.4f}</td>"
            f"<td>{row['mean_trait_std']:.4f}</td>"
            f"<td>{row['mean_inventory_gap']:.4f}</td>"
            f"<td><a href=\"{escape(row['report_path'])}\">profile report</a></td>"
            "</tr>"
        )

    trait_rows = []
    for trait in TRAIT_ORDER:
        row = aggregate["trait_aggregate"][trait]
        trait_rows.append(
            "<tr>"
            f"<td>{escape(row['trait_label'])}</td>"
            f"<td>{row['mean_abs_error']:.4f}</td>"
            f"<td>{row['mean_bias']:.4f}</td>"
            f"<td>{row['mean_std']:.4f}</td>"
            f"<td>{row['target_measured_correlation']:.4f}</td>"
            "</tr>"
        )

    scheme_rows = []
    for row in aggregate["scheme_aggregate"]:
        scheme_rows.append(
            "<tr>"
            f"<td>{escape(row['scheme_id'])}</td>"
            f"<td>{row['profile_count']}</td>"
            f"<td>{row['mean_absolute_error']:.4f}</td>"
            f"<td>{row['mean_trait_std']:.4f}</td>"
            f"<td>{row['distance_retention_ratio']:.4f}</td>"
            "</tr>"
        )

    finding_items = "".join(f"<li>{escape(line)}</li>" for line in aggregate["key_findings"])
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <title>{escape(aggregate['suite_id'])} Report</title>
  <style>
    body {{
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f7f3ea;
      color: #1d241d;
    }}
    .wrap {{
      max-width: 1180px;
      margin: 0 auto;
      padding: 28px 22px 44px;
    }}
    .hero {{
      background: linear-gradient(135deg, #f5d3aa 0%, #d6e6d9 100%);
      border-radius: 24px;
      padding: 28px 30px;
      box-shadow: 0 12px 32px rgba(61, 72, 58, 0.1);
      margin-bottom: 24px;
    }}
    .hero p {{
      color: #445243;
      max-width: 820px;
    }}
    .stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 14px;
      margin-top: 16px;
    }}
    .stat {{
      background: rgba(255, 250, 241, 0.9);
      border-radius: 16px;
      padding: 14px 16px;
      box-shadow: inset 0 0 0 1px rgba(74, 90, 70, 0.08);
    }}
    .section {{
      background: #fffaf1;
      border-radius: 20px;
      padding: 22px;
      box-shadow: 0 8px 24px rgba(61, 72, 58, 0.08);
      margin-bottom: 20px;
    }}
    .section h2 {{
      margin-top: 0;
    }}
    .visual {{
      width: 100%;
      border-radius: 18px;
      display: block;
      background: #fffef9;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      background: #fffdf7;
      border-radius: 18px;
      overflow: hidden;
    }}
    th, td {{
      padding: 12px 10px;
      border-bottom: 1px solid #ece2d4;
      text-align: left;
      vertical-align: top;
    }}
    th {{
      background: #f1e6d3;
    }}
    ul {{
      margin: 0;
      padding-left: 22px;
    }}
    a {{
      color: #2d6a4f;
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>{escape(aggregate['suite_id'])}</h1>
      <p>{escape(aggregate['description'])}</p>
      <div class="stats">
        <div class="stat"><strong>运行模式</strong><br/>{escape(aggregate['execution_mode'])}</div>
        <div class="stat"><strong>人格数量</strong><br/>{aggregate['profile_count']}</div>
        <div class="stat"><strong>总体 MAE</strong><br/>{aggregate['overall_mean_absolute_error']:.4f}</div>
        <div class="stat"><strong>平均稳定性</strong><br/>{aggregate['overall_mean_trait_std']:.4f}</div>
        <div class="stat"><strong>量表一致性</strong><br/>{aggregate['overall_mean_inventory_gap']:.4f}</div>
        <div class="stat"><strong>人格距离保留</strong><br/>{aggregate['profile_separation']['distance_retention_ratio']:.4f}</div>
      </div>
    </div>

    <div class="section">
      <h2>关键发现</h2>
      <ul>{finding_items}</ul>
    </div>

    <div class="section">
      <h2>人格总览矩阵</h2>
      <img class="visual" src="profile_trait_matrix.svg" alt="Profile trait matrix"/>
    </div>

    <div class="section">
      <h2>维度系统性偏差</h2>
      <img class="visual" src="trait_bias.svg" alt="Trait bias chart"/>
    </div>

    <div class="section">
      <h2>方案比较</h2>
      <img class="visual" src="scheme_comparison.svg" alt="Scheme comparison chart"/>
    </div>

    <div class="section">
      <h2>人格级排名</h2>
      <table>
        <thead>
          <tr>
            <th>Profile</th>
            <th>Label</th>
            <th>Scheme</th>
            <th>Seeds</th>
            <th>MAE</th>
            <th>Mean Std</th>
            <th>Inventory Gap</th>
            <th>Detail</th>
          </tr>
        </thead>
        <tbody>
          {''.join(ranking_rows)}
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>维度统计</h2>
      <table>
        <thead>
          <tr>
            <th>Trait</th>
            <th>Mean Abs Error</th>
            <th>Mean Bias</th>
            <th>Mean Std</th>
            <th>Correlation</th>
          </tr>
        </thead>
        <tbody>
          {''.join(trait_rows)}
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>Scheme 统计</h2>
      <table>
        <thead>
          <tr>
            <th>Scheme</th>
            <th>Profiles</th>
            <th>Mean MAE</th>
            <th>Mean Std</th>
            <th>Distance Retention</th>
          </tr>
        </thead>
        <tbody>
          {''.join(scheme_rows)}
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>"""
    path.write_text(html, encoding="utf-8")


def build_profile_trait_matrix_svg(path: Path, aggregate: Dict[str, object]) -> None:
    profiles = aggregate["profiles"]
    section_gap = 40
    left = 220
    top = 76
    cell_width = 86
    cell_height = 32
    section_height = 78 + len(profiles) * cell_height
    width = left + len(TRAIT_ORDER) * cell_width + 80
    height = top + section_height * 3 + section_gap * 2
    pieces = [
        f'<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="34" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Profile Trait Matrix</text>',
        '<text x="34" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Target, measured, and error matrices for all benchmark personas.</text>',
    ]

    for section_index, section_name in enumerate(["Target", "Measured", "Measured - Target"]):
        origin_y = top + section_index * (section_height + section_gap)
        pieces.append(
            f'<text x="34" y="{origin_y + 10}" font-size="20" font-family="Segoe UI, Arial, sans-serif" fill="#2a3328">{section_name}</text>'
        )
        for trait_index, trait in enumerate(TRAIT_ORDER):
            x = left + trait_index * cell_width
            pieces.append(
                f'<text x="{x + cell_width / 2:.1f}" y="{origin_y + 38}" font-size="12" text-anchor="middle" fill="#4d584a">{TRAIT_LABELS[trait]}</text>'
            )
        for row_index, profile in enumerate(profiles):
            y = origin_y + 52 + row_index * cell_height
            pieces.append(
                f'<text x="34" y="{y + 21}" font-size="12" fill="#2d3128">{escape(profile["profile_id"])}</text>'
            )
            for trait_index, trait in enumerate(TRAIT_ORDER):
                x = left + trait_index * cell_width
                if section_name == "Target":
                    value = float(profile[f"{trait}_target"])
                    fill = _trait_color(value)
                    label = f"{value:.1f}"
                elif section_name == "Measured":
                    value = float(profile[f"{trait}_mean"])
                    fill = _trait_color(value)
                    label = f"{value:.1f}"
                else:
                    value = float(profile[f"{trait}_bias"])
                    fill = _error_color(value)
                    label = f"{value:+.1f}"
                pieces.append(
                    f'<rect x="{x}" y="{y}" width="{cell_width - 4}" height="{cell_height - 4}" rx="8" fill="{fill}" stroke="#ede3d2"/>'
                )
                pieces.append(
                    f'<text x="{x + (cell_width - 4) / 2:.1f}" y="{y + 21}" font-size="12" text-anchor="middle" fill="#1f2a1f">{label}</text>'
                )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_trait_bias_svg(path: Path, aggregate: Dict[str, object]) -> None:
    width = 860
    height = 420
    center_x = 420
    bar_max = 250
    top = 88
    row_height = 54
    pieces = [
        '<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="36" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Trait Bias</text>',
        '<text x="36" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Positive values mean the measured profile is higher than the target. Negative values mean the measured profile is lower.</text>',
        f'<line x1="{center_x}" y1="{top - 22}" x2="{center_x}" y2="{height - 36}" stroke="#7f8a7a" stroke-width="1.5"/>',
    ]
    for index, trait in enumerate(TRAIT_ORDER):
        row = aggregate["trait_aggregate"][trait]
        bias = float(row["mean_bias"])
        y = top + index * row_height
        pieces.append(f'<text x="36" y="{y + 19}" font-size="14" fill="#2d3128">{row["trait_label"]}</text>')
        pieces.append(f'<text x="36" y="{y + 36}" font-size="12" fill="#5d6655">Abs error {row["mean_abs_error"]:.2f}</text>')
        width_scale = min(abs(bias), 4.0) / 4.0 * bar_max
        if bias >= 0:
            rect_x = center_x
            fill = "#c36a34"
        else:
            rect_x = center_x - width_scale
            fill = "#3e7c8c"
        pieces.append(
            f'<rect x="{rect_x:.1f}" y="{y + 4}" width="{width_scale:.1f}" height="22" rx="10" fill="{fill}" opacity="0.85"/>'
        )
        pieces.append(
            f'<text x="{center_x + bar_max + 32}" y="{y + 19}" font-size="13" fill="#2d3128">{bias:+.4f}</text>'
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_scheme_comparison_svg(path: Path, aggregate: Dict[str, object]) -> None:
    rows = aggregate["scheme_aggregate"]
    width = 960
    height = 430
    left = 70
    top = 96
    group_width = 180
    bar_width = 40
    max_value = max(
        [row["mean_absolute_error"] for row in rows] + [row["mean_inventory_gap"] for row in rows] + [1.0]
    )
    plot_height = 220
    pieces = [
        '<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="36" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Scheme Comparison</text>',
        '<text x="36" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Grouped bars compare average MAE and average inventory gap across shaping schemes.</text>',
    ]
    for tick in range(5):
        value = max_value * tick / 4
        y = top + plot_height - plot_height * tick / 4
        pieces.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width - 40}" y2="{y:.1f}" stroke="#ebe2d3" stroke-width="1"/>')
        pieces.append(f'<text x="36" y="{y + 4:.1f}" font-size="12" fill="#5d6655">{value:.1f}</text>')
    for index, row in enumerate(rows):
        base_x = left + index * group_width + 38
        mae_height = plot_height * row["mean_absolute_error"] / max_value
        gap_height = plot_height * row["mean_inventory_gap"] / max_value
        pieces.append(
            f'<rect x="{base_x}" y="{top + plot_height - mae_height:.1f}" width="{bar_width}" height="{mae_height:.1f}" rx="10" fill="#c36a34"/>'
        )
        pieces.append(
            f'<rect x="{base_x + 56}" y="{top + plot_height - gap_height:.1f}" width="{bar_width}" height="{gap_height:.1f}" rx="10" fill="#56836a"/>'
        )
        pieces.append(
            f'<text x="{base_x + 20}" y="{top + plot_height + 22}" font-size="11" text-anchor="middle" fill="#2d3128">MAE</text>'
        )
        pieces.append(
            f'<text x="{base_x + 76}" y="{top + plot_height + 22}" font-size="11" text-anchor="middle" fill="#2d3128">Gap</text>'
        )
        pieces.append(
            f'<text x="{base_x + 48}" y="{top + plot_height + 46}" font-size="11" text-anchor="middle" fill="#4b5647">{escape(row["scheme_id"])}</text>'
        )
        pieces.append(
            f'<text x="{base_x + 20}" y="{top + plot_height - mae_height - 8:.1f}" font-size="11" text-anchor="middle" fill="#2d3128">{row["mean_absolute_error"]:.2f}</text>'
        )
        pieces.append(
            f'<text x="{base_x + 76}" y="{top + plot_height - gap_height - 8:.1f}" font-size="11" text-anchor="middle" fill="#2d3128">{row["mean_inventory_gap"]:.2f}</text>'
        )

    pieces.append('<rect x="690" y="88" width="18" height="18" fill="#c36a34"/>')
    pieces.append('<text x="714" y="102" font-size="13" fill="#2d3128">Mean MAE</text>')
    pieces.append('<rect x="690" y="116" width="18" height="18" fill="#56836a"/>')
    pieces.append('<text x="714" y="130" font-size="13" fill="#2d3128">Mean inventory gap</text>')

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def _write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _trait_color(value: float) -> str:
    low = (62, 124, 140)
    mid = (242, 232, 212)
    high = (188, 103, 51)
    scaled = max(1.0, min(9.0, value))
    if scaled <= 5.0:
        t = (scaled - 1.0) / 4.0
        rgb = _lerp_rgb(low, mid, t)
    else:
        t = (scaled - 5.0) / 4.0
        rgb = _lerp_rgb(mid, high, t)
    return _rgb_to_hex(rgb)


def _error_color(value: float) -> str:
    negative = (58, 120, 145)
    neutral = (241, 236, 224)
    positive = (189, 101, 53)
    scaled = max(-4.0, min(4.0, value))
    if scaled <= 0.0:
        t = (scaled + 4.0) / 4.0
        rgb = _lerp_rgb(negative, neutral, t)
    else:
        t = scaled / 4.0
        rgb = _lerp_rgb(neutral, positive, t)
    return _rgb_to_hex(rgb)


def _lerp_rgb(left: tuple[int, int, int], right: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    clipped = max(0.0, min(1.0, t))
    return (
        round(left[0] + (right[0] - left[0]) * clipped),
        round(left[1] + (right[1] - left[1]) * clipped),
        round(left[2] + (right[2] - left[2]) * clipped),
    )


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def _euclidean(xs: List[float], ys: List[float]) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(xs, ys)))


def _pearson(xs: List[float], ys: List[float]) -> float:
    if len(xs) != len(ys) or len(xs) <= 1:
        return 0.0
    mx = mean(xs)
    my = mean(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    if dx == 0.0 or dy == 0.0:
        return 0.0
    return numerator / (dx * dy)
