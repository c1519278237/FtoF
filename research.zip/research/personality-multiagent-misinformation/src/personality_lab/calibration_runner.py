from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from .catalog import load_shaping_library, resolve_profile, resolve_scheme
from .json_utils import dump_json, load_json
from .persona import TRAIT_ORDER
from .validation_runner import run_persona_validation


def calibrate_persona(
    *,
    profile_id: Optional[str] = None,
    trait_targets: Optional[Dict[str, int]] = None,
    label: Optional[str] = None,
    description: Optional[str] = None,
    scheme_id: Optional[str] = None,
    inventory_ids: Optional[List[str]] = None,
    model_name: str,
    seed_count: int,
    iterations: int,
    output_dir: Path,
    dry_run: bool = False,
) -> Path:
    library = load_shaping_library()
    profile = resolve_profile(
        library,
        profile_id=profile_id,
        trait_targets=trait_targets,
        label=label,
        description=description,
        recommended_scheme=scheme_id or "calibrated_precision",
    )
    effective_scheme_id = scheme_id or profile.get("recommended_scheme") or "calibrated_precision"
    scheme = resolve_scheme(library, effective_scheme_id)
    gain = float(scheme.get("calibration_gain", 1.0))
    desired_targets = {trait: int(profile["trait_targets"][trait]) for trait in TRAIT_ORDER}
    control_targets = dict(desired_targets)

    output_dir.mkdir(parents=True, exist_ok=True)
    history = []

    for iteration in range(1, iterations + 1):
        iteration_dir = output_dir / f"iter_{iteration}"
        run_persona_validation(
            profile_id=profile.get("id"),
            trait_targets=None if profile_id else desired_targets,
            label=profile["label"],
            description=profile["description"],
            scheme_id=effective_scheme_id,
            inventory_ids=inventory_ids,
            model_name=model_name,
            seed_count=seed_count,
            output_dir=iteration_dir,
            dry_run=dry_run,
            control_targets=control_targets,
        )
        summary = load_json(iteration_dir / "summary.json")
        measured = {trait: float(summary["traits"][trait]["mean"]) for trait in TRAIT_ORDER}
        errors = {trait: round(desired_targets[trait] - measured[trait], 4) for trait in TRAIT_ORDER}
        history.append(
            {
                "iteration": iteration,
                "control_targets": dict(control_targets),
                "measured": measured,
                "errors": errors,
                "mean_absolute_error": summary["mean_absolute_error"],
            }
        )

        next_control_targets = {}
        for trait in TRAIT_ORDER:
            corrected = round(control_targets[trait] + gain * (desired_targets[trait] - measured[trait]))
            next_control_targets[trait] = max(1, min(9, int(corrected)))
        control_targets = next_control_targets

    best_run = min(history, key=lambda item: item["mean_absolute_error"])
    recommendation = {
        "profile_id": profile["id"],
        "label": profile["label"],
        "scheme_id": effective_scheme_id,
        "desired_targets": desired_targets,
        "recommended_control_targets": best_run["control_targets"],
        "best_iteration": best_run["iteration"],
        "best_mean_absolute_error": best_run["mean_absolute_error"],
        "history": history,
    }
    dump_json(output_dir / "calibration_history.json", recommendation)
    return output_dir
