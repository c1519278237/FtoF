from __future__ import annotations

from copy import deepcopy
from typing import Dict, Optional

from .json_utils import load_json
from .paths import project_path


TRAIT_ALIASES = {
    "e": "extraversion",
    "extraversion": "extraversion",
    "a": "agreeableness",
    "agreeableness": "agreeableness",
    "c": "conscientiousness",
    "conscientiousness": "conscientiousness",
    "n": "neuroticism",
    "neuroticism": "neuroticism",
    "o": "openness",
    "openness": "openness",
}


def load_shaping_library() -> Dict[str, object]:
    return load_json(project_path("configs", "paper_shaping_library.json"))


def resolve_scheme(library: Dict[str, object], scheme_id: str) -> Dict[str, object]:
    schemes = library["scheme_templates"]
    if scheme_id not in schemes:
        raise RuntimeError(f"Unknown scheme_id: {scheme_id}")
    scheme = deepcopy(schemes[scheme_id])
    scheme["id"] = scheme_id
    return scheme


def resolve_named_profile(library: Dict[str, object], profile_id: str) -> Dict[str, object]:
    profiles = library["named_profiles"]
    if profile_id not in profiles:
        raise RuntimeError(f"Unknown profile_id: {profile_id}")
    return deepcopy(profiles[profile_id])


def parse_trait_targets(spec: str) -> Dict[str, int]:
    if not spec:
        raise RuntimeError("Trait specification is empty.")
    targets: Dict[str, int] = {}
    for raw_part in spec.split(","):
        part = raw_part.strip()
        if not part or "=" not in part:
            raise RuntimeError(f"Invalid trait assignment: {raw_part}")
        key, value = part.split("=", 1)
        key = key.strip().lower()
        if key not in TRAIT_ALIASES:
            raise RuntimeError(f"Unknown trait alias: {key}")
        trait = TRAIT_ALIASES[key]
        score = int(value.strip())
        if score < 1 or score > 9:
            raise RuntimeError(f"Trait {trait} must be within 1-9, got {score}")
        targets[trait] = score
    missing = [trait for trait in ["extraversion", "agreeableness", "conscientiousness", "neuroticism", "openness"] if trait not in targets]
    if missing:
        raise RuntimeError(f"Missing trait assignments for: {', '.join(missing)}")
    return targets


def build_custom_profile(
    trait_targets: Dict[str, int],
    label: Optional[str] = None,
    description: Optional[str] = None,
    recommended_scheme: str = "calibrated_precision",
) -> Dict[str, object]:
    safe_label = label or "Custom Persona"
    safe_description = description or "A custom personality profile generated from user-specified Big Five targets."
    profile_id = safe_label.lower().replace(" ", "_")
    return {
        "id": profile_id,
        "label": safe_label,
        "trait_targets": deepcopy(trait_targets),
        "description": safe_description,
        "recommended_scheme": recommended_scheme,
        "baseline_mode": False,
        "use_case": "Custom user-defined personality profile."
    }


def resolve_profile(
    library: Dict[str, object],
    profile_id: Optional[str] = None,
    trait_targets: Optional[Dict[str, int]] = None,
    label: Optional[str] = None,
    description: Optional[str] = None,
    recommended_scheme: str = "calibrated_precision",
) -> Dict[str, object]:
    if profile_id:
        return resolve_named_profile(library, profile_id)
    if trait_targets:
        return build_custom_profile(
            trait_targets=trait_targets,
            label=label,
            description=description,
            recommended_scheme=recommended_scheme,
        )
    raise RuntimeError("Either profile_id or trait_targets must be provided.")
