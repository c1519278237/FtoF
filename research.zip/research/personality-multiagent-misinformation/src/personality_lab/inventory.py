from __future__ import annotations

from typing import Dict, List


def render_item_prompt(item: Dict[str, object], options: List[Dict[str, object]]) -> str:
    option_lines = [f"{option['code']}. {option['label']}" for option in options]
    return "\n".join(
        [
            "Answer the following personality statement using exactly one option letter.",
            "Return only one capital letter from A to E.",
            "",
            f"Statement: {item['text']}",
            "",
            "Options:",
            *option_lines,
        ]
    )
