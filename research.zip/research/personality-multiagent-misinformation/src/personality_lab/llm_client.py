from __future__ import annotations

import json
import http.client
import math
import os
import re
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from .json_utils import load_json
from .paths import project_path


LETTER_RE = re.compile(r"[A-E]")


@dataclass
class LikertResult:
    choice: str
    choice_score: float
    distribution: Dict[str, float]
    expected_score: float
    used_logprobs: bool
    raw_content: str


@dataclass
class ModelSpec:
    source: str
    requested_name: str
    model_name: str
    alias: str
    label: str
    provider_id: str
    client_type: str
    base_url: str
    api_key_env: str
    timeout_seconds: int = 60
    supports_logprobs: Optional[bool] = None
    max_top_logprobs: int = 20


class OpenAICompatibleClient:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        timeout_seconds: int = 60,
        max_retries: int = 3,
        retry_backoff_seconds: float = 2.0,
        max_top_logprobs: int = 20,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self.retry_backoff_seconds = retry_backoff_seconds
        self.max_top_logprobs = max_top_logprobs

    def _post_json(self, payload: Dict[str, object]) -> Dict[str, object]:
        last_error: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                data = json.dumps(payload).encode("utf-8")
                request = urllib.request.Request(
                    url=f"{self.base_url}/chat/completions",
                    data=data,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                retryable = exc.code in {408, 409, 425, 429, 500, 502, 503, 504}
                wrapped = RuntimeError(f"HTTP {exc.code}: {body}")
                if not retryable or attempt == self.max_retries:
                    raise wrapped from exc
                last_error = wrapped
            except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionResetError, http.client.RemoteDisconnected, OSError) as exc:
                if attempt == self.max_retries:
                    raise
                last_error = exc
            time.sleep(self.retry_backoff_seconds * attempt)
        if last_error:
            raise RuntimeError(f"Model request failed after retries: {last_error}")
        raise RuntimeError("Model request failed without a specific error.")

    def ask_likert(
        self,
        system_prompt: str,
        user_prompt: str,
        option_score_map: Dict[str, float],
        temperature: float = 0.0,
        top_logprobs: int = 20,
    ) -> LikertResult:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 1,
            "logprobs": True,
            "top_logprobs": min(top_logprobs, self.max_top_logprobs),
        }
        try:
            response = self._post_json(payload)
            return self._parse_likert_response(response, option_score_map, used_logprobs=True)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            if "logprobs" not in body.lower():
                raise RuntimeError(f"Model request failed: HTTP {exc.code}: {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Model request failed: {exc}") from exc

        fallback_payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 4,
        }
        try:
            response = self._post_json(fallback_payload)
            return self._parse_likert_response(response, option_score_map, used_logprobs=False)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Model request failed: HTTP {exc.code}: {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Model request failed: {exc}") from exc

    def _parse_likert_response(
        self,
        response: Dict[str, object],
        option_score_map: Dict[str, float],
        used_logprobs: bool,
    ) -> LikertResult:
        choices = response.get("choices", [])
        if not choices:
            raise RuntimeError("Model response contained no choices.")
        first_choice = choices[0]
        message = first_choice.get("message", {})
        content = (message.get("content") or "").strip()
        choice = self._extract_choice_letter(content)

        distribution = {}
        if used_logprobs:
            distribution = self._extract_distribution_from_logprobs(first_choice, option_score_map)
            used_logprobs = bool(distribution)

        if not distribution:
            distribution = {letter: 1.0 if letter == choice else 0.0 for letter in option_score_map}

        expected_score = sum(distribution[letter] * option_score_map[letter] for letter in distribution)
        return LikertResult(
            choice=choice,
            choice_score=option_score_map[choice],
            distribution=distribution,
            expected_score=expected_score,
            used_logprobs=used_logprobs,
            raw_content=content,
        )

    @staticmethod
    def _extract_choice_letter(content: str) -> str:
        match = LETTER_RE.search(content.upper())
        if not match:
            return "C"
        return match.group(0)

    @staticmethod
    def _extract_distribution_from_logprobs(
        choice: Dict[str, object],
        option_score_map: Dict[str, float],
    ) -> Dict[str, float]:
        logprobs = choice.get("logprobs")
        if not logprobs:
            return {}
        content = logprobs.get("content")
        if not content:
            return {}
        first_token = content[0] if content else {}
        top_logprobs = first_token.get("top_logprobs") or []
        scores: Dict[str, float] = {}
        for candidate in top_logprobs:
            token = (candidate.get("token") or "").strip().upper()
            if token in option_score_map:
                scores[token] = float(candidate.get("logprob", float("-inf")))
        if not scores:
            return {}
        max_logprob = max(scores.values())
        exp_scores = {token: math.exp(logprob - max_logprob) for token, logprob in scores.items()}
        total = sum(exp_scores.values())
        normalized = {token: value / total for token, value in exp_scores.items()}
        for token in option_score_map:
            normalized.setdefault(token, 0.0)
        return normalized


def load_model_registry(registry_path: Optional[Path] = None) -> Dict[str, object]:
    path = registry_path or project_path("configs", "model_registry.json")
    if not path.exists():
        return {"models": {}}
    return load_json(path)


def list_model_aliases(registry_path: Optional[Path] = None, include_disabled: bool = False) -> list[str]:
    registry = load_model_registry(registry_path)
    aliases = []
    for alias, config in registry.get("models", {}).items():
        enabled = bool(config.get("enabled", True))
        if include_disabled or enabled:
            aliases.append(alias)
    return sorted(aliases)


def resolve_model_spec(
    requested_name: str = "qwen-plus",
    registry_path: Optional[Path] = None,
) -> ModelSpec:
    registry = load_model_registry(registry_path)
    models = registry.get("models", {})
    if requested_name in models:
        config = models[requested_name]
        if not bool(config.get("enabled", True)):
            raise RuntimeError(f"Model alias '{requested_name}' is disabled in the registry.")
        return _resolve_registry_model(requested_name, config)
    return _resolve_env_fallback_model(requested_name)


def build_client_from_env(default_model: str = "qwen-plus") -> OpenAICompatibleClient:
    spec = resolve_model_spec(default_model)
    return build_client_from_spec(spec)


def build_client_from_spec(spec: ModelSpec) -> OpenAICompatibleClient:
    api_key = os.environ.get(spec.api_key_env)
    if not api_key:
        raise RuntimeError(
            f"Missing API key environment variable '{spec.api_key_env}' for model '{spec.alias}'."
        )
    if spec.client_type != "openai_compatible":
        raise RuntimeError(f"Unsupported client_type: {spec.client_type}")
    return OpenAICompatibleClient(
        base_url=spec.base_url,
        api_key=api_key,
        model=spec.model_name,
        timeout_seconds=spec.timeout_seconds,
        max_top_logprobs=spec.max_top_logprobs,
    )


def _resolve_registry_model(alias: str, config: Dict[str, object]) -> ModelSpec:
    client_type = str(config.get("client_type", "openai_compatible"))
    provider_id = str(config.get("provider_id", "openai_compatible"))
    label = str(config.get("label", alias))
    base_url = _resolve_with_env_override(
        env_name=str(config.get("base_url_env", "")).strip(),
        fallback=str(config.get("base_url", "")).strip(),
    )
    if not base_url:
        raise RuntimeError(f"Model alias '{alias}' is missing a base_url.")
    model_name = _resolve_with_env_override(
        env_name=str(config.get("model_env", "")).strip(),
        fallback=str(config.get("model", alias)).strip(),
    )
    api_key_env = str(config.get("api_key_env", "")).strip()
    if not api_key_env:
        raise RuntimeError(f"Model alias '{alias}' is missing api_key_env.")
    timeout_seconds = int(config.get("timeout_seconds", 60))
    supports_logprobs = config.get("supports_logprobs")
    if supports_logprobs is not None:
        supports_logprobs = bool(supports_logprobs)
    max_top_logprobs = int(config.get("max_top_logprobs", 20))
    return ModelSpec(
        source="registry",
        requested_name=alias,
        model_name=model_name,
        alias=alias,
        label=label,
        provider_id=provider_id,
        client_type=client_type,
        base_url=base_url,
        api_key_env=api_key_env,
        timeout_seconds=timeout_seconds,
        supports_logprobs=supports_logprobs,
        max_top_logprobs=max_top_logprobs,
    )


def _resolve_env_fallback_model(requested_name: str) -> ModelSpec:
    api_key_env, _ = _first_present_env(
        [
            "PERSONALITY_LAB_API_KEY",
            "AI_BAILIAN_API_KEY",
            "DASHSCOPE_API_KEY",
        ]
    )
    if not api_key_env:
        raise RuntimeError(
            "Missing PERSONALITY_LAB_API_KEY, AI_BAILIAN_API_KEY, or DASHSCOPE_API_KEY."
        )
    base_url = os.environ.get(
        "PERSONALITY_LAB_BASE_URL",
        "https://dashscope.aliyuncs.com/compatible-mode/v1",
    )
    model_name = os.environ.get("PERSONALITY_LAB_MODEL", requested_name)
    provider_id = os.environ.get("PERSONALITY_LAB_PROVIDER_ID", "env_openai_compatible")
    label = os.environ.get("PERSONALITY_LAB_MODEL_LABEL", model_name)
    return ModelSpec(
        source="env_fallback",
        requested_name=requested_name,
        model_name=model_name,
        alias=requested_name,
        label=label,
        provider_id=provider_id,
        client_type="openai_compatible",
        base_url=base_url,
        api_key_env=api_key_env,
        timeout_seconds=int(os.environ.get("PERSONALITY_LAB_TIMEOUT_SECONDS", "60")),
        supports_logprobs=None,
        max_top_logprobs=int(os.environ.get("PERSONALITY_LAB_MAX_TOP_LOGPROBS", "20")),
    )


def _resolve_with_env_override(env_name: str, fallback: str) -> str:
    if env_name:
        value = os.environ.get(env_name)
        if value:
            return value
    return fallback


def _first_present_env(env_names: list[str]) -> tuple[str, str]:
    for env_name in env_names:
        value = os.environ.get(env_name)
        if value:
            return env_name, value
    return "", ""
