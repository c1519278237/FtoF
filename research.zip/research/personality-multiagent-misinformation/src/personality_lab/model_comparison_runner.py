from __future__ import annotations

import csv
from collections import defaultdict
from datetime import datetime
from html import escape
from pathlib import Path
from statistics import mean
from typing import Dict, List

from .benchmark_runner import run_benchmark_suite
from .json_utils import dump_json, load_json
from .llm_client import resolve_model_spec
from .persona import TRAIT_LABELS, TRAIT_ORDER
from .paths import repo_path


def run_model_comparison_suite(
    *,
    comparison_config_path: Path,
    output_dir: Path,
    benchmark_suite_path: Path | None = None,
    selected_models: List[str] | None = None,
    dry_run: bool = False,
    continue_on_error: bool = False,
) -> Path:
    comparison_config = load_json(comparison_config_path)
    output_dir.mkdir(parents=True, exist_ok=True)

    benchmark_path = benchmark_suite_path or _resolve_path(
        Path(str(comparison_config["benchmark_suite_config"]))
    )
    model_ids = selected_models or list(comparison_config.get("models", []))
    results = []
    failures = []

    for model_id in model_ids:
        model_output_dir = output_dir / model_id
        try:
            run_benchmark_suite(
                suite_config_path=benchmark_path,
                output_dir=model_output_dir,
                model_name=model_id,
                dry_run=dry_run,
            )
            results.append(load_json(model_output_dir / "aggregate_summary.json"))
        except Exception as exc:
            failures.append(
                {
                    "model_alias": model_id,
                    "error": str(exc),
                }
            )
            if not continue_on_error:
                raise

    aggregate = build_model_comparison_summary(
        comparison_config=comparison_config,
        output_dir=output_dir,
        benchmark_suite_path=benchmark_path,
        model_results=results,
        failures=failures,
        dry_run=dry_run,
    )
    write_model_comparison_outputs(output_dir, aggregate, failures)
    return output_dir


def rebuild_model_comparison_outputs(
    *,
    comparison_config_path: Path,
    output_dir: Path,
    benchmark_suite_path: Path | None = None,
    selected_models: List[str] | None = None,
    dry_run: bool = False,
) -> Path:
    comparison_config = load_json(comparison_config_path)
    benchmark_path = benchmark_suite_path or _resolve_path(
        Path(str(comparison_config["benchmark_suite_config"]))
    )
    model_ids = selected_models or list(comparison_config.get("models", []))
    results = []
    failures = []
    for model_id in model_ids:
        aggregate_path = output_dir / model_id / "aggregate_summary.json"
        if aggregate_path.exists():
            results.append(load_json(aggregate_path))
        else:
            failures.append(
                {
                    "model_alias": model_id,
                    "error": f"Missing aggregate_summary.json in {aggregate_path.parent}",
                }
            )
    aggregate = build_model_comparison_summary(
        comparison_config=comparison_config,
        output_dir=output_dir,
        benchmark_suite_path=benchmark_path,
        model_results=results,
        failures=failures,
        dry_run=dry_run,
    )
    write_model_comparison_outputs(output_dir, aggregate, failures)
    return output_dir


def build_model_comparison_summary(
    *,
    comparison_config: Dict[str, object],
    output_dir: Path,
    benchmark_suite_path: Path,
    model_results: List[Dict[str, object]],
    failures: List[Dict[str, str]],
    dry_run: bool,
) -> Dict[str, object]:
    model_rows = []
    trait_rows = []
    profile_rows = []
    scheme_rows = []

    for result in model_results:
        alias = str(result.get("model_alias", result.get("model", "unknown")))
        label = str(result.get("model_label", alias))
        provider = str(result.get("model_provider", "unknown"))
        try:
            spec = resolve_model_spec(alias)
            resolved_model_name = spec.model_name
        except Exception:
            resolved_model_name = str(result.get("model", alias))
        model_rows.append(
            {
                "model_alias": alias,
                "model_label": label,
                "provider_id": provider,
                "resolved_model_name": resolved_model_name,
                "profile_count": result["profile_count"],
                "overall_mean_absolute_error": result["overall_mean_absolute_error"],
                "overall_mean_trait_std": result["overall_mean_trait_std"],
                "overall_mean_inventory_gap": result["overall_mean_inventory_gap"],
                "distance_retention_ratio": result["profile_separation"]["distance_retention_ratio"],
                "best_profile_id": result["ranking"][0]["profile_id"],
                "best_profile_mae": result["ranking"][0]["mean_absolute_error"],
                "worst_profile_id": result["ranking"][-1]["profile_id"],
                "worst_profile_mae": result["ranking"][-1]["mean_absolute_error"],
                "report_path": f"{alias}/report.html",
            }
        )

        for trait in TRAIT_ORDER:
            trait_summary = result["trait_aggregate"][trait]
            trait_rows.append(
                {
                    "model_alias": alias,
                    "model_label": label,
                    "provider_id": provider,
                    "trait": trait,
                    "trait_label": TRAIT_LABELS[trait],
                    "mean_abs_error": trait_summary["mean_abs_error"],
                    "mean_bias": trait_summary["mean_bias"],
                    "mean_std": trait_summary["mean_std"],
                    "mean_inventory_gap": trait_summary["mean_inventory_gap"],
                    "target_measured_correlation": trait_summary["target_measured_correlation"],
                }
            )

        for profile in result["profiles"]:
            profile_rows.append(
                {
                    "model_alias": alias,
                    "model_label": label,
                    "provider_id": provider,
                    "profile_id": profile["profile_id"],
                    "persona_label": profile["persona_label"],
                    "scheme_id": profile["scheme_id"],
                    "mean_absolute_error": profile["mean_absolute_error"],
                    "mean_trait_std": profile["mean_trait_std"],
                    "mean_inventory_gap": profile["mean_inventory_gap"],
                }
            )

        for scheme in result.get("scheme_aggregate", []):
            scheme_rows.append(
                {
                    "model_alias": alias,
                    "model_label": label,
                    "provider_id": provider,
                    "scheme_id": scheme["scheme_id"],
                    "profile_count": scheme["profile_count"],
                    "mean_absolute_error": scheme["mean_absolute_error"],
                    "mean_trait_std": scheme["mean_trait_std"],
                    "mean_inventory_gap": scheme["mean_inventory_gap"],
                    "distance_retention_ratio": scheme["distance_retention_ratio"],
                }
            )

    if not model_rows:
        raise RuntimeError("No successful model results were produced.")

    ranking = sorted(model_rows, key=lambda row: row["overall_mean_absolute_error"])
    stability_ranking = sorted(model_rows, key=lambda row: row["overall_mean_trait_std"])
    consistency_ranking = sorted(model_rows, key=lambda row: row["overall_mean_inventory_gap"])
    best_model_per_trait = _build_best_model_per_trait(trait_rows)
    best_model_per_profile = _build_best_model_per_profile(profile_rows)
    best_model = ranking[0]
    worst_model = ranking[-1]

    return {
        "suite_id": comparison_config["suite_id"],
        "description": comparison_config["description"],
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "execution_mode": "dry-run" if dry_run else "live",
        "benchmark_suite_path": str(benchmark_suite_path),
        "output_dir": str(output_dir),
        "model_count": len(model_rows),
        "failure_count": len(failures),
        "models": model_rows,
        "trait_rows": trait_rows,
        "profile_rows": profile_rows,
        "scheme_rows": scheme_rows,
        "ranking": ranking,
        "stability_ranking": stability_ranking,
        "consistency_ranking": consistency_ranking,
        "best_model_per_trait": best_model_per_trait,
        "best_model_per_profile": best_model_per_profile,
        "failures": failures,
        "overall_mean_absolute_error": round(mean(row["overall_mean_absolute_error"] for row in model_rows), 4),
        "overall_mean_trait_std": round(mean(row["overall_mean_trait_std"] for row in model_rows), 4),
        "overall_mean_inventory_gap": round(mean(row["overall_mean_inventory_gap"] for row in model_rows), 4),
        "key_findings": [
            f"整体人格塑形精度最好的模型是 {best_model['model_alias']}，总体 MAE={best_model['overall_mean_absolute_error']:.4f}。",
            f"整体人格塑形精度最弱的模型是 {worst_model['model_alias']}，总体 MAE={worst_model['overall_mean_absolute_error']:.4f}。",
            f"跨人格稳定性最好的模型是 {stability_ranking[0]['model_alias']}，平均跨 seed 标准差={stability_ranking[0]['overall_mean_trait_std']:.4f}。",
            f"跨量表一致性最好的模型是 {consistency_ranking[0]['model_alias']}，平均量表差={consistency_ranking[0]['overall_mean_inventory_gap']:.4f}。",
            f"成功完成评测的模型数为 {len(model_rows)}，失败模型数为 {len(failures)}。",
        ],
    }


def write_model_comparison_outputs(
    output_dir: Path,
    aggregate: Dict[str, object],
    failures: List[Dict[str, str]],
) -> None:
    dump_json(output_dir / "aggregate_model_summary.json", aggregate)
    dump_json(output_dir / "model_failures.json", failures)
    write_model_table(output_dir / "model_table.csv", aggregate["models"])
    write_model_trait_table(output_dir / "model_trait_table.csv", aggregate["trait_rows"])
    write_model_profile_table(output_dir / "model_profile_table.csv", aggregate["profile_rows"])
    write_model_scheme_table(output_dir / "model_scheme_table.csv", aggregate["scheme_rows"])
    build_model_overview_svg(output_dir / "model_overview.svg", aggregate)
    build_model_trait_heatmap_svg(output_dir / "model_trait_heatmap.svg", aggregate)
    build_profile_model_heatmap_svg(output_dir / "profile_model_heatmap.svg", aggregate)
    write_markdown_report(output_dir / "多模型总报告.md", aggregate)
    write_interpretation_report(output_dir / "多模型结果解读.md", aggregate)
    write_html_report(output_dir / "report.html", aggregate)


def write_model_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "model_alias",
        "model_label",
        "provider_id",
        "resolved_model_name",
        "profile_count",
        "overall_mean_absolute_error",
        "overall_mean_trait_std",
        "overall_mean_inventory_gap",
        "distance_retention_ratio",
        "best_profile_id",
        "best_profile_mae",
        "worst_profile_id",
        "worst_profile_mae",
        "report_path",
    ]
    _write_csv(path, rows, fieldnames)


def write_model_trait_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "model_alias",
        "model_label",
        "provider_id",
        "trait",
        "trait_label",
        "mean_abs_error",
        "mean_bias",
        "mean_std",
        "mean_inventory_gap",
        "target_measured_correlation",
    ]
    _write_csv(path, rows, fieldnames)


def write_model_profile_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "model_alias",
        "model_label",
        "provider_id",
        "profile_id",
        "persona_label",
        "scheme_id",
        "mean_absolute_error",
        "mean_trait_std",
        "mean_inventory_gap",
    ]
    _write_csv(path, rows, fieldnames)


def write_model_scheme_table(path: Path, rows: List[Dict[str, object]]) -> None:
    fieldnames = [
        "model_alias",
        "model_label",
        "provider_id",
        "scheme_id",
        "profile_count",
        "mean_absolute_error",
        "mean_trait_std",
        "mean_inventory_gap",
        "distance_retention_ratio",
    ]
    _write_csv(path, rows, fieldnames)


def write_markdown_report(path: Path, aggregate: Dict[str, object]) -> None:
    ranking_lines = [
        f"{index + 1}. `{row['model_alias']}` (`{row['model_label']}`), MAE=`{row['overall_mean_absolute_error']:.4f}`，稳定性=`{row['overall_mean_trait_std']:.4f}`，量表差=`{row['overall_mean_inventory_gap']:.4f}`"
        for index, row in enumerate(aggregate["ranking"])
    ]
    trait_lines = []
    for trait in TRAIT_ORDER:
        row = aggregate["best_model_per_trait"][trait]
        trait_lines.append(
            f"- `{TRAIT_LABELS[trait]}` 最佳模型：`{row['model_alias']}`，平均绝对误差 `{row['mean_abs_error']:.4f}`。"
        )
    profile_lines = []
    for profile_id, row in sorted(aggregate["best_model_per_profile"].items()):
        profile_lines.append(
            f"- `{profile_id}` 最佳模型：`{row['model_alias']}`，MAE `{row['mean_absolute_error']:.4f}`。"
        )
    failure_lines = [
        f"- `{failure['model_alias']}`: {failure['error']}" for failure in aggregate["failures"]
    ] or ["- 无失败模型。"]
    text = "\n".join(
        [
            f"# {aggregate['suite_id']} 多模型总报告",
            "",
            aggregate["description"],
            "",
            "## 实验设置",
            f"- 生成时间：`{aggregate['generated_at']}`",
            f"- 运行模式：`{aggregate['execution_mode']}`",
            f"- 参考人格基准：`{aggregate['benchmark_suite_path']}`",
            f"- 成功模型数：`{aggregate['model_count']}`",
            f"- 失败模型数：`{aggregate['failure_count']}`",
            "",
            "## 总体指标",
            f"- 模型间平均 MAE：`{aggregate['overall_mean_absolute_error']:.4f}`",
            f"- 模型间平均跨 seed 标准差：`{aggregate['overall_mean_trait_std']:.4f}`",
            f"- 模型间平均跨量表差：`{aggregate['overall_mean_inventory_gap']:.4f}`",
            "",
            "## 总体排名",
            *ranking_lines,
            "",
            "## 各维度最佳模型",
            *trait_lines,
            "",
            "## 各人格最佳模型",
            *profile_lines,
            "",
            "## 失败记录",
            *failure_lines,
        ]
    )
    path.write_text(text, encoding="utf-8")


def write_interpretation_report(path: Path, aggregate: Dict[str, object]) -> None:
    best_model = aggregate["ranking"][0]
    worst_model = aggregate["ranking"][-1]
    best_stability = aggregate["stability_ranking"][0]
    best_consistency = aggregate["consistency_ranking"][0]
    text = "\n".join(
        [
            "# 多模型人格塑形结果解读",
            "",
            "## 1. 这轮实验在回答什么问题",
            "",
            "这轮实验的核心问题不是“某个人格能不能塑出来”，而是“不同大模型对人格塑形是否同样敏感、同样可控”。",
            "因此我们把同一套人格基准固定下来，只更换底层大模型，比较它们的人格塑形精度、稳定性、量表一致性和跨人格适应性。",
            "",
            "## 2. 总体结论",
            "",
            f"- 综合精度最好的模型是 `{best_model['model_alias']}`，总体 MAE 为 `{best_model['overall_mean_absolute_error']:.4f}`。",
            f"- 综合精度最差的模型是 `{worst_model['model_alias']}`，总体 MAE 为 `{worst_model['overall_mean_absolute_error']:.4f}`。",
            f"- 最稳定的模型是 `{best_stability['model_alias']}`，说明它对不同 lexical seeds 更不敏感。",
            f"- 跨量表一致性最好的模型是 `{best_consistency['model_alias']}`，说明它塑出来的人格在不同问卷上的测量更一致。",
            "",
            "## 3. 如何理解“模型适应性”",
            "",
            "- 如果一个模型总体 MAE 更低，说明它更容易被人格提示精准塑形。",
            "- 如果一个模型总体标准差更低，说明它的人格表现更稳定。",
            "- 如果一个模型跨量表差更低，说明它的人格不是只对某一份问卷有效，而是更接近跨量表一致的人格结构。",
            "- 如果某模型只在少数人格上很好、但在其他人格上明显失控，就说明它的塑形适应性是局部的，不是全面的。",
            "",
            "## 4. 如何理解“塑造能力”",
            "",
            "- “塑造能力”主要看它能否把目标人格拉到正确方向，尤其是在高神经质、低开放、低尽责这些困难维度上。",
            "- 如果某模型在多数维度都有同方向偏差，例如总是过高的宜人性、过高的开放性，就说明它存在强默认人格先验。",
            "- 因此后续下游多智能体实验，最好优先选择既准又稳、且跨量表一致的模型。",
            "",
            "## 5. 使用建议",
            "",
            "- 先用这份多模型总报告筛掉塑形能力明显不足的模型。",
            "- 再从剩余模型里，为关键人格单独做一次校准。",
            "- 最后把“模型类型”作为正式实验中的一个自变量，与“人格类型”共同进入统计分析。",
        ]
    )
    path.write_text(text, encoding="utf-8")


def write_html_report(path: Path, aggregate: Dict[str, object]) -> None:
    model_rows = []
    for row in aggregate["ranking"]:
        model_rows.append(
            "<tr>"
            f"<td>{escape(row['model_alias'])}</td>"
            f"<td>{escape(row['model_label'])}</td>"
            f"<td>{escape(row['provider_id'])}</td>"
            f"<td>{row['overall_mean_absolute_error']:.4f}</td>"
            f"<td>{row['overall_mean_trait_std']:.4f}</td>"
            f"<td>{row['overall_mean_inventory_gap']:.4f}</td>"
            f"<td>{row['distance_retention_ratio']:.4f}</td>"
            f"<td><a href=\"{escape(row['report_path'])}\">benchmark report</a></td>"
            "</tr>"
        )
    finding_items = "".join(f"<li>{escape(line)}</li>" for line in aggregate["key_findings"])
    failure_items = "".join(
        f"<li><strong>{escape(item['model_alias'])}</strong>: {escape(item['error'])}</li>"
        for item in aggregate["failures"]
    ) or "<li>无失败模型。</li>"
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <title>{escape(aggregate['suite_id'])} Report</title>
  <style>
    body {{
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f7f3ea;
      color: #1d241d;
    }}
    .wrap {{
      max-width: 1180px;
      margin: 0 auto;
      padding: 28px 22px 44px;
    }}
    .hero {{
      background: linear-gradient(135deg, #f5d3aa 0%, #d6e6d9 100%);
      border-radius: 24px;
      padding: 28px 30px;
      box-shadow: 0 12px 32px rgba(61, 72, 58, 0.1);
      margin-bottom: 24px;
    }}
    .stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 14px;
      margin-top: 16px;
    }}
    .stat {{
      background: rgba(255, 250, 241, 0.9);
      border-radius: 16px;
      padding: 14px 16px;
    }}
    .section {{
      background: #fffaf1;
      border-radius: 20px;
      padding: 22px;
      box-shadow: 0 8px 24px rgba(61, 72, 58, 0.08);
      margin-bottom: 20px;
    }}
    img {{
      width: 100%;
      display: block;
      border-radius: 18px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      background: #fffdf7;
      border-radius: 18px;
      overflow: hidden;
    }}
    th, td {{
      padding: 12px 10px;
      border-bottom: 1px solid #ece2d4;
      text-align: left;
      vertical-align: top;
    }}
    th {{
      background: #f1e6d3;
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>{escape(aggregate['suite_id'])}</h1>
      <p>{escape(aggregate['description'])}</p>
      <div class="stats">
        <div class="stat"><strong>运行模式</strong><br/>{escape(aggregate['execution_mode'])}</div>
        <div class="stat"><strong>成功模型数</strong><br/>{aggregate['model_count']}</div>
        <div class="stat"><strong>失败模型数</strong><br/>{aggregate['failure_count']}</div>
        <div class="stat"><strong>平均 MAE</strong><br/>{aggregate['overall_mean_absolute_error']:.4f}</div>
        <div class="stat"><strong>平均稳定性</strong><br/>{aggregate['overall_mean_trait_std']:.4f}</div>
        <div class="stat"><strong>平均量表差</strong><br/>{aggregate['overall_mean_inventory_gap']:.4f}</div>
      </div>
    </div>

    <div class="section">
      <h2>关键发现</h2>
      <ul>{finding_items}</ul>
    </div>

    <div class="section">
      <h2>模型总览</h2>
      <img src="model_overview.svg" alt="Model overview"/>
    </div>

    <div class="section">
      <h2>模型-维度热力图</h2>
      <img src="model_trait_heatmap.svg" alt="Model trait heatmap"/>
    </div>

    <div class="section">
      <h2>人格-模型热力图</h2>
      <img src="profile_model_heatmap.svg" alt="Profile model heatmap"/>
    </div>

    <div class="section">
      <h2>模型排名</h2>
      <table>
        <thead>
          <tr>
            <th>Alias</th>
            <th>Label</th>
            <th>Provider</th>
            <th>Overall MAE</th>
            <th>Mean Std</th>
            <th>Inventory Gap</th>
            <th>Distance Retention</th>
            <th>Detail</th>
          </tr>
        </thead>
        <tbody>
          {''.join(model_rows)}
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>失败记录</h2>
      <ul>{failure_items}</ul>
    </div>
  </div>
</body>
</html>"""
    path.write_text(html, encoding="utf-8")


def build_model_overview_svg(path: Path, aggregate: Dict[str, object]) -> None:
    rows = aggregate["ranking"]
    width = 980
    height = 140 + len(rows) * 56
    left = 240
    top = 88
    bar_max = 360
    max_mae = max(row["overall_mean_absolute_error"] for row in rows) or 1.0
    pieces = [
        '<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="34" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Model Overview</text>',
        '<text x="34" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Lower MAE is better. Smaller stability and inventory-gap values indicate more reliable personality shaping.</text>',
    ]
    for index, row in enumerate(rows):
        y = top + index * 56
        pieces.append(f'<text x="34" y="{y + 18}" font-size="14" fill="#2d3128">{escape(row["model_alias"])}</text>')
        pieces.append(f'<text x="34" y="{y + 36}" font-size="12" fill="#5d6655">{escape(row["resolved_model_name"])}</text>')
        mae_width = bar_max * row["overall_mean_absolute_error"] / max_mae
        pieces.append(f'<rect x="{left}" y="{y}" width="{bar_max}" height="16" rx="8" fill="#efe4d4"/>')
        pieces.append(f'<rect x="{left}" y="{y}" width="{mae_width:.1f}" height="16" rx="8" fill="#c36a34"/>')
        pieces.append(f'<text x="{left + bar_max + 16}" y="{y + 13}" font-size="12" fill="#2d3128">MAE {row["overall_mean_absolute_error"]:.4f}</text>')
        pieces.append(f'<text x="{left}" y="{y + 36}" font-size="12" fill="#5d6655">std {row["overall_mean_trait_std"]:.4f} | gap {row["overall_mean_inventory_gap"]:.4f} | retention {row["distance_retention_ratio"]:.4f}</text>')

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_model_trait_heatmap_svg(path: Path, aggregate: Dict[str, object]) -> None:
    models = [row["model_alias"] for row in aggregate["ranking"]]
    trait_map = {
        (row["model_alias"], row["trait"]): row["mean_abs_error"]
        for row in aggregate["trait_rows"]
    }
    width = 190 + len(TRAIT_ORDER) * 110
    height = 120 + len(models) * 42
    left = 170
    top = 82
    pieces = [
        '<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="34" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Model-Trait Heatmap</text>',
        '<text x="34" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Cells show per-trait mean absolute error. Lighter is better.</text>',
    ]
    max_value = max(trait_map.values()) or 1.0
    for trait_index, trait in enumerate(TRAIT_ORDER):
        x = left + trait_index * 110
        pieces.append(f'<text x="{x + 46}" y="{top - 16}" font-size="12" text-anchor="middle" fill="#4d584a">{TRAIT_LABELS[trait]}</text>')
    for row_index, model_alias in enumerate(models):
        y = top + row_index * 42
        pieces.append(f'<text x="34" y="{y + 20}" font-size="13" fill="#2d3128">{escape(model_alias)}</text>')
        for trait_index, trait in enumerate(TRAIT_ORDER):
            value = trait_map[(model_alias, trait)]
            intensity = value / max_value if max_value else 0.0
            fill = _interpolate_color("#f7f2e8", "#c36a34", intensity)
            x = left + trait_index * 110
            pieces.append(f'<rect x="{x}" y="{y}" width="92" height="28" rx="8" fill="{fill}" stroke="#eadfcd"/>')
            pieces.append(f'<text x="{x + 46}" y="{y + 18}" font-size="12" text-anchor="middle" fill="#1f2a1f">{value:.2f}</text>')
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_profile_model_heatmap_svg(path: Path, aggregate: Dict[str, object]) -> None:
    models = [row["model_alias"] for row in aggregate["ranking"]]
    profile_ids = sorted({row["profile_id"] for row in aggregate["profile_rows"]})
    profile_map = {
        (row["profile_id"], row["model_alias"]): row["mean_absolute_error"]
        for row in aggregate["profile_rows"]
    }
    width = 220 + len(models) * 110
    height = 120 + len(profile_ids) * 38
    left = 190
    top = 82
    max_value = max(profile_map.values()) or 1.0
    pieces = [
        '<rect width="100%" height="100%" fill="#fbf7ef"/>',
        '<text x="34" y="42" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">Profile-Model Heatmap</text>',
        '<text x="34" y="66" font-size="13" font-family="Segoe UI, Arial, sans-serif" fill="#5d6655">Cells show per-profile MAE under each model. Lighter is better.</text>',
    ]
    for model_index, model_alias in enumerate(models):
        x = left + model_index * 110
        pieces.append(f'<text x="{x + 46}" y="{top - 16}" font-size="12" text-anchor="middle" fill="#4d584a">{escape(model_alias)}</text>')
    for row_index, profile_id in enumerate(profile_ids):
        y = top + row_index * 38
        pieces.append(f'<text x="34" y="{y + 18}" font-size="12" fill="#2d3128">{escape(profile_id)}</text>')
        for model_index, model_alias in enumerate(models):
            value = profile_map.get((profile_id, model_alias))
            if value is None:
                fill = "#f4efe6"
                label = "-"
            else:
                fill = _interpolate_color("#f7f2e8", "#8a3b1f", value / max_value if max_value else 0.0)
                label = f"{value:.2f}"
            x = left + model_index * 110
            pieces.append(f'<rect x="{x}" y="{y}" width="92" height="24" rx="8" fill="{fill}" stroke="#eadfcd"/>')
            pieces.append(f'<text x="{x + 46}" y="{y + 16}" font-size="11" text-anchor="middle" fill="#1f2a1f">{label}</text>')
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  {''.join(pieces)}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def _build_best_model_per_trait(rows: List[Dict[str, object]]) -> Dict[str, Dict[str, object]]:
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["trait"]].append(row)
    return {
        trait: min(grouped[trait], key=lambda row: row["mean_abs_error"])
        for trait in TRAIT_ORDER
    }


def _build_best_model_per_profile(rows: List[Dict[str, object]]) -> Dict[str, Dict[str, object]]:
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["profile_id"]].append(row)
    return {
        profile_id: min(profile_rows, key=lambda row: row["mean_absolute_error"])
        for profile_id, profile_rows in grouped.items()
    }


def _write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _resolve_path(raw_path: Path) -> Path:
    if raw_path.is_absolute():
        return raw_path
    repo_candidate = repo_path(str(raw_path))
    if repo_candidate.exists():
        return repo_candidate
    return raw_path


def _interpolate_color(left_hex: str, right_hex: str, t: float) -> str:
    left = _hex_to_rgb(left_hex)
    right = _hex_to_rgb(right_hex)
    clipped = max(0.0, min(1.0, t))
    rgb = tuple(round(l + (r - l) * clipped) for l, r in zip(left, right))
    return _rgb_to_hex(rgb)


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    raw = value.lstrip("#")
    return int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16)


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)
