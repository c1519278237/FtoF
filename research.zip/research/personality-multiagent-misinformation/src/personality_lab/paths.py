from __future__ import annotations

from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_ROOT.parent.parent
REPO_ROOT = PROJECT_ROOT.parent.parent


def project_path(*parts: str) -> Path:
    return PROJECT_ROOT.joinpath(*parts)


def repo_path(*parts: str) -> Path:
    return REPO_ROOT.joinpath(*parts)
