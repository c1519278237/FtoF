from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Tuple


TRAIT_ORDER = [
    "extraversion",
    "agreeableness",
    "conscientiousness",
    "neuroticism",
    "openness",
]

TRAIT_LABELS = {
    "extraversion": "Extraversion",
    "agreeableness": "Agreeableness",
    "conscientiousness": "Conscientiousness",
    "neuroticism": "Neuroticism",
    "openness": "Openness",
}

LEVEL_QUALIFIERS = {
    1: "extremely low",
    2: "very low",
    3: "low",
    4: "somewhat low",
    5: "balanced",
    6: "somewhat high",
    7: "high",
    8: "very high",
    9: "extremely high",
}


@dataclass
class PersonaPrompt:
    system_prompt: str
    marker_summary: Dict[str, Dict[str, List[str]]]
    trait_instructions: Dict[str, str]
    scheme_id: str
    scheme_description: str
    profile_label: str


def _trait_direction(level: int) -> str:
    if level >= 6:
        return "high"
    if level <= 4:
        return "low"
    return "balanced"


def _sample_markers(markers: List[str], sample_size: int, seed_key: str) -> List[str]:
    if len(markers) <= sample_size:
        return list(markers)
    rng = random.Random(seed_key)
    return sorted(rng.sample(markers, sample_size))


def build_persona_prompt(
    shared_role: Dict[str, str],
    persona: Dict[str, object],
    shaping_library: Dict[str, object],
    scheme_id: str,
    lexical_seed: int,
    control_targets: Dict[str, int] | None = None,
) -> PersonaPrompt:
    scheme = shaping_library["scheme_templates"][scheme_id]
    baseline_mode = bool(persona.get("baseline_mode")) or scheme_id == "baseline_control"
    trait_specs = shaping_library["traits"]
    big_five = control_targets or persona["trait_targets"]
    sections: List[str] = []
    marker_summary: Dict[str, Dict[str, List[str]]] = {}
    trait_instructions: Dict[str, str] = {}

    if baseline_mode:
        system_prompt = "\n".join(
            [
                "You are participating in a controlled personality validation experiment.",
                "",
                "Stable role:",
                shared_role["description"],
                "",
                "Baseline instruction:",
                "Do not adopt any special personality style beyond the shared lawyer role.",
                "Answer consistently as the same lawyer persona across all items and turns.",
                "",
                "Measurement rule:",
                "When answering a questionnaire item, respond only with the single best Likert option.",
                "Do not explain your choice unless explicitly asked.",
            ]
        )
        return PersonaPrompt(
            system_prompt=system_prompt,
            marker_summary={},
            trait_instructions={},
            scheme_id=scheme_id,
            scheme_description=scheme["description"],
            profile_label=persona["label"],
        )

    for trait in TRAIT_ORDER:
        level = int(big_five[trait])
        qualifier = shaping_library["qualifier_levels"][str(level)]
        direction = _trait_direction(level)
        trait_spec = trait_specs[trait]
        markers = {
            "high": trait_spec["high_markers"],
            "low": trait_spec["low_markers"],
        }
        markers_per_trait = int(scheme["markers_per_trait"])
        high_markers = _sample_markers(
            markers["high"],
            markers_per_trait,
            f"{persona['id']}:{lexical_seed}:{trait}:high",
        )
        low_markers = _sample_markers(
            markers["low"],
            markers_per_trait,
            f"{persona['id']}:{lexical_seed}:{trait}:low",
        )
        marker_summary[trait] = {
            "high": high_markers,
            "low": low_markers,
        }

        if direction == "balanced":
            parts = [
                f"- {TRAIT_LABELS[trait]}: balanced (5/9). Stay between {', '.join(trait_spec['balanced_anchors'])}; do not drift too strongly toward either pole."
            ]
            if scheme.get("include_balanced_anchors"):
                parts.append(
                    f"Favor neither extreme {', '.join(high_markers[:2])} nor extreme {', '.join(low_markers[:2])}."
                )
            if scheme.get("include_behavioral_anchors"):
                parts.append(trait_spec["behavioral_anchors"]["balanced"])
            if scheme.get("include_task_controls"):
                parts.append(trait_spec["task_controls"]["balanced"])
            instruction = " ".join(parts)
            sections.append(instruction)
            trait_instructions[trait] = instruction
        elif direction == "high":
            parts = [
                f"- {TRAIT_LABELS[trait]}: {qualifier} ({level}/9). Lean toward {', '.join(high_markers)} rather than {', '.join(low_markers[:4])}."
            ]
            if scheme.get("include_facets"):
                parts.append(f"Express high facets such as {', '.join(trait_spec['high_facets'])}.")
            if scheme.get("include_behavioral_anchors"):
                parts.append(trait_spec["behavioral_anchors"]["high"])
            if scheme.get("include_task_controls"):
                parts.append(trait_spec["task_controls"]["high"])
            instruction = " ".join(parts)
            sections.append(instruction)
            trait_instructions[trait] = instruction
        else:
            parts = [
                f"- {TRAIT_LABELS[trait]}: {qualifier} ({level}/9). Lean toward {', '.join(low_markers)} rather than {', '.join(high_markers[:4])}."
            ]
            if scheme.get("include_facets"):
                parts.append(f"Express low-direction facets such as {', '.join(trait_spec['low_facets'])}.")
            if scheme.get("include_behavioral_anchors"):
                parts.append(trait_spec["behavioral_anchors"]["low"])
            if scheme.get("include_task_controls"):
                parts.append(trait_spec["task_controls"]["low"])
            instruction = " ".join(parts)
            sections.append(instruction)
            trait_instructions[trait] = instruction

    trait_summary = ", ".join(
        f"{TRAIT_LABELS[trait]}={big_five[trait]}/9" for trait in TRAIT_ORDER
    )

    system_prompt = "\n".join(
        [
            "You are participating in a controlled personality shaping experiment.",
            "",
            "Stable role:",
            shared_role["description"],
            "",
            "Target personality profile:",
            f"- Persona: {persona['label']}",
            f"- Summary: {trait_summary}",
            f"- Description: {persona['description']}",
            f"- Scheme: {scheme_id} ({scheme['description']})",
            "",
            "Trait-level lexical shaping instructions:",
            *sections,
            "",
            "Consistency rule:",
            "Maintain the same stable dispositional profile across all items and turns.",
            "Treat the target traits as enduring tendencies in how you think, judge, challenge, and respond.",
            "Do not randomly vary the persona from one item to the next.",
            "",
            "Measurement rule:",
            "When answering a questionnaire item, respond only with the single best Likert option.",
            "Do not explain your choice unless explicitly asked.",
        ]
    )
    return PersonaPrompt(
        system_prompt=system_prompt,
        marker_summary=marker_summary,
        trait_instructions=trait_instructions,
        scheme_id=scheme_id,
        scheme_description=scheme["description"],
        profile_label=persona["label"],
    )


def target_profile(persona: Dict[str, object]) -> List[Tuple[str, float]]:
    target_map = persona.get("trait_targets") or persona.get("big_five") or {}
    return [(trait, float(target_map[trait])) for trait in TRAIT_ORDER]
