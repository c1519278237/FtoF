from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Dict, List

from .json_utils import dump_json
from .persona import TRAIT_LABELS, TRAIT_ORDER


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def build_radar_svg(
    target_scores: Dict[str, float],
    measured_scores: Dict[str, float],
    path: Path,
    title: str,
) -> None:
    width = 760
    height = 520
    cx = 260
    cy = 260
    radius = 170
    levels = 5
    axes = len(TRAIT_ORDER)

    def point_for(trait_index: int, value: float) -> tuple[float, float]:
        angle = -math.pi / 2 + 2 * math.pi * trait_index / axes
        scaled = max(0.0, min(9.0, value)) / 9.0 * radius
        x = cx + math.cos(angle) * scaled
        y = cy + math.sin(angle) * scaled
        return (x, y)

    def polygon_points(scores: Dict[str, float]) -> str:
        points = [point_for(index, scores.get(trait, 5.0)) for index, trait in enumerate(TRAIT_ORDER)]
        return " ".join(f"{x:.2f},{y:.2f}" for x, y in points)

    rings = []
    for level in range(1, levels + 1):
        ring_value = 9.0 * level / levels
        points = " ".join(
            f"{point_for(index, ring_value)[0]:.2f},{point_for(index, ring_value)[1]:.2f}"
            for index in range(axes)
        )
        rings.append(f'<polygon points="{points}" fill="none" stroke="#d7d4c8" stroke-width="1"/>')

    axis_lines = []
    axis_labels = []
    for index, trait in enumerate(TRAIT_ORDER):
        x, y = point_for(index, 9.0)
        axis_lines.append(f'<line x1="{cx}" y1="{cy}" x2="{x:.2f}" y2="{y:.2f}" stroke="#c8c4b5" stroke-width="1"/>')
        lx, ly = point_for(index, 10.0)
        axis_labels.append(
            f'<text x="{lx:.2f}" y="{ly:.2f}" font-size="14" text-anchor="middle" fill="#2d3128">{TRAIT_LABELS[trait]}</text>'
        )

    target_points = polygon_points(target_scores)
    measured_points = polygon_points(measured_scores)

    legend = """
    <rect x="500" y="110" width="18" height="18" fill="#d96b3b" opacity="0.28" stroke="#d96b3b"/>
    <text x="526" y="124" font-size="14" fill="#2d3128">Target profile</text>
    <rect x="500" y="145" width="18" height="18" fill="#2d7f78" opacity="0.28" stroke="#2d7f78"/>
    <text x="526" y="159" font-size="14" fill="#2d3128">Measured profile</text>
    """

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="100%" height="100%" fill="#f7f1e3"/>
  <text x="40" y="48" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">{title}</text>
  <text x="40" y="78" font-size="14" font-family="Segoe UI, Arial, sans-serif" fill="#5c6654">Paper-inspired target traits versus measured questionnaire profile (1-9 scale)</text>
  {''.join(rings)}
  {''.join(axis_lines)}
  <polygon points="{target_points}" fill="#d96b3b" opacity="0.28" stroke="#d96b3b" stroke-width="3"/>
  <polygon points="{measured_points}" fill="#2d7f78" opacity="0.28" stroke="#2d7f78" stroke-width="3"/>
  {''.join(axis_labels)}
  {legend}
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_bar_svg(
    target_scores: Dict[str, float],
    measured_scores: Dict[str, float],
    std_scores: Dict[str, float],
    path: Path,
    title: str,
) -> None:
    width = 860
    height = 440
    left = 80
    top = 90
    row_height = 56
    bar_max_width = 300

    rows = []
    for index, trait in enumerate(TRAIT_ORDER):
        y = top + index * row_height
        target = max(0.0, min(9.0, target_scores.get(trait, 5.0)))
        measured = max(0.0, min(9.0, measured_scores.get(trait, 5.0)))
        std = max(0.0, std_scores.get(trait, 0.0))
        target_width = bar_max_width * (target / 9.0)
        measured_width = bar_max_width * (measured / 9.0)
        rows.append(
            "\n".join(
                [
                    f'<text x="{left}" y="{y + 18}" font-size="14" fill="#2d3128">{TRAIT_LABELS[trait]}</text>',
                    f'<rect x="{left + 160}" y="{y}" width="{bar_max_width}" height="16" fill="#efe4c7"/>',
                    f'<rect x="{left + 160}" y="{y}" width="{target_width:.2f}" height="16" fill="#d96b3b" opacity="0.55"/>',
                    f'<rect x="{left + 160}" y="{y + 22}" width="{bar_max_width}" height="16" fill="#e4ece8"/>',
                    f'<rect x="{left + 160}" y="{y + 22}" width="{measured_width:.2f}" height="16" fill="#2d7f78" opacity="0.78"/>',
                    f'<text x="{left + 480}" y="{y + 12}" font-size="12" fill="#5c6654">target {target:.2f}</text>',
                    f'<text x="{left + 480}" y="{y + 34}" font-size="12" fill="#5c6654">measured {measured:.2f} | std {std:.2f}</text>',
                ]
            )
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="100%" height="100%" fill="#fbf7ee"/>
  <text x="40" y="48" font-size="28" font-family="Segoe UI, Arial, sans-serif" fill="#1f2a1f">{title}</text>
  <text x="40" y="76" font-size="14" font-family="Segoe UI, Arial, sans-serif" fill="#5c6654">Per-trait target, measured mean, and cross-seed stability</text>
  {''.join(rows)}
  <rect x="600" y="110" width="18" height="18" fill="#d96b3b" opacity="0.55"/>
  <text x="626" y="124" font-size="14" fill="#2d3128">Target</text>
  <rect x="600" y="140" width="18" height="18" fill="#2d7f78" opacity="0.78"/>
  <text x="626" y="154" font-size="14" fill="#2d3128">Measured mean</text>
</svg>"""
    path.write_text(svg, encoding="utf-8")


def build_html_report(
    output_dir: Path,
    persona_label: str,
    summary: Dict[str, object],
    radar_file: str,
    bar_file: str,
) -> None:
    rows = []
    for trait in TRAIT_ORDER:
        trait_summary = summary["traits"][trait]
        rows.append(
            f"<tr><td>{TRAIT_LABELS[trait]}</td><td>{trait_summary['target']:.2f}</td><td>{trait_summary['mean']:.2f}</td><td>{trait_summary['std']:.2f}</td></tr>"
        )
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>{persona_label} Personality Validation</title>
  <style>
    body {{
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f5efe3;
      color: #1f2a1f;
    }}
    .wrap {{
      max-width: 980px;
      margin: 0 auto;
      padding: 32px 24px 48px;
    }}
    .hero {{
      background: linear-gradient(135deg, #f7d7b5 0%, #d9ebdf 100%);
      border-radius: 24px;
      padding: 28px 30px;
      margin-bottom: 28px;
      box-shadow: 0 14px 36px rgba(64, 74, 58, 0.12);
    }}
    .grid {{
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
    }}
    .card {{
      background: #fffaf0;
      border-radius: 22px;
      padding: 20px;
      box-shadow: 0 10px 30px rgba(49, 58, 42, 0.08);
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }}
    th, td {{
      text-align: left;
      padding: 12px 10px;
      border-bottom: 1px solid #e6decf;
    }}
    .meta {{
      display: flex;
      gap: 22px;
      flex-wrap: wrap;
      margin-top: 14px;
      color: #5c6654;
    }}
    img {{
      width: 100%;
      border-radius: 18px;
      display: block;
    }}
    code {{
      background: #efe6d4;
      padding: 2px 6px;
      border-radius: 6px;
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>{persona_label} Personality Validation</h1>
      <p>This report summarizes a paper-inspired personality shaping run: lexical marker conditioning, Likert-style questionnaire measurement, and cross-seed trait stability.</p>
      <div class="meta">
        <span>Model: <code>{summary['model']}</code></span>
        <span>Inventory: <code>{summary['inventory_id']}</code></span>
        <span>Seeds: <code>{summary['seed_count']}</code></span>
        <span>Logprob mode used: <code>{summary['used_logprobs']}</code></span>
        <span>Mean absolute error: <code>{summary['mean_absolute_error']:.2f}</code></span>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <h2>Radar Profile</h2>
        <img src="{radar_file}" alt="Radar chart"/>
      </div>
      <div class="card">
        <h2>Trait Comparison</h2>
        <img src="{bar_file}" alt="Bar chart"/>
      </div>
      <div class="card">
        <h2>Trait Table</h2>
        <table>
          <thead>
            <tr>
              <th>Trait</th>
              <th>Target</th>
              <th>Measured Mean</th>
              <th>Across-Seed Std</th>
            </tr>
          </thead>
          <tbody>
            {''.join(rows)}
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>"""
    output_dir.joinpath("report.html").write_text(html, encoding="utf-8")


def write_summary(output_dir: Path, summary: Dict[str, object]) -> None:
    dump_json(output_dir / "summary.json", summary)
