from __future__ import annotations

import math
from statistics import mean
from typing import Dict, Iterable, List


def reverse_score(score: float) -> float:
    return 6.0 - score


def mean_or_zero(values: Iterable[float]) -> float:
    values = list(values)
    if not values:
        return 0.0
    return mean(values)


def transform_1_to_5_into_1_to_9(score: float) -> float:
    return 1.0 + (score - 1.0) * 2.0


def trait_scores_from_responses(items: List[Dict[str, object]], responses: List[Dict[str, object]]) -> Dict[str, float]:
    item_map = {item["id"]: item for item in items}
    bucket: Dict[str, List[float]] = {}
    for response in responses:
        item = item_map[response["item_id"]]
        trait = item["trait"]
        score = float(response["expected_score"])
        if item.get("reverse"):
            score = reverse_score(score)
        bucket.setdefault(trait, []).append(score)
    return {trait: transform_1_to_5_into_1_to_9(mean_or_zero(values)) for trait, values in bucket.items()}


def aggregate_trait_scores(score_maps: List[Dict[str, float]]) -> Dict[str, float]:
    bucket: Dict[str, List[float]] = {}
    for score_map in score_maps:
        for trait, value in score_map.items():
            bucket.setdefault(trait, []).append(float(value))
    return {trait: mean_or_zero(values) for trait, values in bucket.items()}


def cronbach_alpha(items: List[Dict[str, object]], responses: List[Dict[str, object]], trait: str) -> float:
    item_map = {item["id"]: item for item in items}
    rows = []
    for response in responses:
        item = item_map[response["item_id"]]
        if item["trait"] != trait:
            continue
        score = float(response["expected_score"])
        if item.get("reverse"):
            score = reverse_score(score)
        rows.append(score)
    if len(rows) < 2:
        return 0.0
    item_variance = _sample_variance(rows)
    total_variance = _sample_variance([sum(rows)])
    if total_variance == 0.0:
        return 1.0
    k = len(rows)
    return (k / (k - 1.0)) * (1.0 - (k * item_variance) / total_variance)


def _sample_variance(values: List[float]) -> float:
    if len(values) <= 1:
        return 0.0
    avg = mean(values)
    return sum((value - avg) ** 2 for value in values) / (len(values) - 1)


def mean_absolute_error(measured: Dict[str, float], target: Dict[str, float]) -> float:
    traits = sorted(set(measured) & set(target))
    if not traits:
        return 0.0
    return sum(abs(measured[trait] - target[trait]) for trait in traits) / len(traits)


def standard_deviation(values: List[float]) -> float:
    if len(values) <= 1:
        return 0.0
    avg = mean(values)
    return math.sqrt(sum((value - avg) ** 2 for value in values) / (len(values) - 1))
