from __future__ import annotations

from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Dict, List, Optional

from .catalog import load_shaping_library, resolve_profile, resolve_scheme
from .dotenv_utils import load_dotenv
from .inventory import render_item_prompt
from .json_utils import dump_json, load_json
from .llm_client import build_client_from_spec, resolve_model_spec
from .paths import project_path, repo_path
from .persona import TRAIT_ORDER, build_persona_prompt
from .reporting import build_bar_svg, build_html_report, build_radar_svg, write_csv, write_summary
from .scoring import aggregate_trait_scores, mean_absolute_error, standard_deviation, trait_scores_from_responses


def run_persona_validation(
    *,
    profile_id: Optional[str] = None,
    trait_targets: Optional[Dict[str, int]] = None,
    label: Optional[str] = None,
    description: Optional[str] = None,
    scheme_id: Optional[str] = None,
    inventory_ids: Optional[List[str]] = None,
    model_name: str,
    seed_count: int,
    output_dir: Path,
    dry_run: bool = False,
    control_targets: Optional[Dict[str, int]] = None,
) -> Path:
    load_dotenv(repo_path(".env"))
    library = load_shaping_library()
    profile = resolve_profile(
        library,
        profile_id=profile_id,
        trait_targets=trait_targets,
        label=label,
        description=description,
        recommended_scheme=scheme_id or "calibrated_precision",
    )
    effective_scheme_id = scheme_id or profile.get("recommended_scheme") or "paper_standard"
    scheme = resolve_scheme(library, effective_scheme_id)
    selected_inventory_ids = inventory_ids or scheme.get("default_inventory_ids") or library.get("default_inventory_ids") or ["mini_ipip_20"]
    inventories = [
        load_json(project_path("configs", "inventories", f"{inventory_id}.json"))
        for inventory_id in selected_inventory_ids
    ]

    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = None if dry_run else resolve_model_spec(model_name)
    client = None if dry_run else build_client_from_spec(model_spec)
    all_response_rows: List[Dict[str, object]] = []
    run_summaries: List[Dict[str, object]] = []
    prompt_snapshots: List[Dict[str, object]] = []

    for lexical_seed in range(1, seed_count + 1):
        prompt_bundle = build_persona_prompt(
            library["shared_role"],
            profile,
            library,
            effective_scheme_id,
            lexical_seed=lexical_seed,
            control_targets=control_targets,
        )
        prompt_snapshots.append(
            {
                "lexical_seed": lexical_seed,
                "system_prompt": prompt_bundle.system_prompt,
                "marker_summary": prompt_bundle.marker_summary,
                "trait_instructions": prompt_bundle.trait_instructions,
                "scheme_id": prompt_bundle.scheme_id,
            }
        )

        per_inventory_scores: Dict[str, Dict[str, float]] = {}
        seed_used_logprobs = False

        for inventory in inventories:
            options = inventory["response_options"]
            option_score_map = {option["code"]: float(option["score"]) for option in options}
            inventory_responses: List[Dict[str, object]] = []
            for item in inventory["items"]:
                if dry_run:
                    result = _simulate_likert_response(item, control_targets or profile["trait_targets"], option_score_map)
                else:
                    result = client.ask_likert(
                        system_prompt=prompt_bundle.system_prompt,
                        user_prompt=render_item_prompt(item, options),
                        option_score_map=option_score_map,
                        temperature=0.0,
                    )
                response_row = {
                    "persona_id": profile["id"],
                    "persona_label": profile["label"],
                    "scheme_id": effective_scheme_id,
                    "lexical_seed": lexical_seed,
                    "inventory_id": inventory["id"],
                    "item_id": item["id"],
                    "trait": item["trait"],
                    "reverse": item["reverse"],
                    "choice": result.choice,
                    "choice_score": round(result.choice_score, 4),
                    "expected_score": round(result.expected_score, 4),
                    "used_logprobs": result.used_logprobs,
                    "raw_content": result.raw_content,
                }
                for option_code in option_score_map:
                    response_row[f"p_{option_code}"] = round(result.distribution.get(option_code, 0.0), 6)
                inventory_responses.append(response_row)
                all_response_rows.append(response_row)
                seed_used_logprobs = seed_used_logprobs or result.used_logprobs

            per_inventory_scores[inventory["id"]] = trait_scores_from_responses(inventory["items"], inventory_responses)

        aggregated_trait_scores = aggregate_trait_scores(list(per_inventory_scores.values()))
        run_summaries.append(
            {
                "lexical_seed": lexical_seed,
                "trait_scores": aggregated_trait_scores,
                "trait_scores_by_inventory": per_inventory_scores,
                "used_logprobs": seed_used_logprobs,
                "marker_summary": prompt_bundle.marker_summary,
                "trait_instructions": prompt_bundle.trait_instructions,
            }
        )

    targets = {trait: float((control_targets or profile["trait_targets"])[trait]) for trait in TRAIT_ORDER}
    desired_targets = {trait: float(profile["trait_targets"][trait]) for trait in TRAIT_ORDER}

    trait_means = {
        trait: mean(summary["trait_scores"][trait] for summary in run_summaries)
        for trait in TRAIT_ORDER
    }
    trait_stds = {
        trait: standard_deviation([summary["trait_scores"][trait] for summary in run_summaries])
        for trait in TRAIT_ORDER
    }
    per_inventory_trait_means = {
        inventory_id: {
            trait: mean(summary["trait_scores_by_inventory"][inventory_id][trait] for summary in run_summaries)
            for trait in TRAIT_ORDER
        }
        for inventory_id in selected_inventory_ids
    }

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    summary = {
        "generated_at": timestamp,
        "requested_model": model_name,
        "model": model_spec.model_name if model_spec else model_name,
        "model_alias": model_spec.alias if model_spec else model_name,
        "model_label": model_spec.label if model_spec else model_name,
        "model_provider": model_spec.provider_id if model_spec else "dry-run",
        "model_client_type": model_spec.client_type if model_spec else "dry-run",
        "model_source": model_spec.source if model_spec else "dry-run",
        "model_base_url": model_spec.base_url if model_spec else "dry-run",
        "model_api_key_env": model_spec.api_key_env if model_spec else "dry-run",
        "profile_id": profile["id"],
        "persona_id": profile["id"],
        "persona_label": profile["label"],
        "profile_description": profile["description"],
        "scheme_id": effective_scheme_id,
        "scheme_description": scheme["description"],
        "inventory_id": ",".join(selected_inventory_ids),
        "inventory_ids": selected_inventory_ids,
        "seed_count": seed_count,
        "used_logprobs": any(summary["used_logprobs"] for summary in run_summaries),
        "mean_absolute_error": round(mean_absolute_error(trait_means, desired_targets), 4),
        "target_profile": desired_targets,
        "control_profile": targets,
        "traits": {
            trait: {
                "target": round(desired_targets[trait], 4),
                "control_target": round(targets[trait], 4),
                "mean": round(trait_means[trait], 4),
                "std": round(trait_stds[trait], 4),
                "by_inventory": {
                    inventory_id: round(per_inventory_trait_means[inventory_id][trait], 4)
                    for inventory_id in selected_inventory_ids
                },
                "inventory_gap": round(
                    max(per_inventory_trait_means[inventory_id][trait] for inventory_id in selected_inventory_ids)
                    - min(per_inventory_trait_means[inventory_id][trait] for inventory_id in selected_inventory_ids),
                    4,
                ),
            }
            for trait in TRAIT_ORDER
        },
        "runs": run_summaries,
    }

    write_summary(output_dir, summary)
    dump_json(output_dir / "profile_spec.json", profile)
    dump_json(output_dir / "prompt_snapshots.json", prompt_snapshots)
    write_csv(
        output_dir / "responses.csv",
        all_response_rows,
        fieldnames=[
            "persona_id",
            "persona_label",
            "scheme_id",
            "lexical_seed",
            "inventory_id",
            "item_id",
            "trait",
            "reverse",
            "choice",
            "choice_score",
            "expected_score",
            "used_logprobs",
            "raw_content",
            "p_A",
            "p_B",
            "p_C",
            "p_D",
            "p_E",
        ],
    )
    radar_name = "trait_radar.svg"
    bar_name = "trait_bars.svg"
    build_radar_svg(desired_targets, trait_means, output_dir / radar_name, title=f"{profile['label']} Radar")
    build_bar_svg(desired_targets, trait_means, trait_stds, output_dir / bar_name, title=f"{profile['label']} Trait Comparison")
    build_html_report(output_dir, profile["label"], summary, radar_name, bar_name)
    return output_dir


def _simulate_likert_response(
    item: Dict[str, object],
    target_profile: Dict[str, int],
    option_score_map: Dict[str, float],
):
    class _SimulatedResult:
        def __init__(self, choice: str, score: float):
            self.choice = choice
            self.choice_score = score
            self.expected_score = score
            self.used_logprobs = False
            self.raw_content = choice
            self.distribution = {letter: 1.0 if letter == choice else 0.0 for letter in option_score_map}

    target = int(target_profile[item["trait"]])
    mapped_score = max(1, min(5, round(1 + (target - 1) / 2)))
    if item.get("reverse"):
        mapped_score = 6 - mapped_score
    reverse_option_map = {int(score): letter for letter, score in option_score_map.items()}
    choice = reverse_option_map.get(mapped_score, "C")
    return _SimulatedResult(choice=choice, score=float(mapped_score))
